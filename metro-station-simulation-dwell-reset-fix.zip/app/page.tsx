import { Simulator } from "@/components/metro/simulator"

export default function Page() {
  return <Simulator />
}
