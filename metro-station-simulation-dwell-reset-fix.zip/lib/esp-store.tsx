"use client"

import {
  createContext,
  useContext,
  useReducer,
  useCallback,
  type ReactNode,
} from "react"

export type StationMode = "elevated" | "underground"
export type TrackId = "A" | "B"
export type TrackState = "clear" | "occupied"

export interface LogEntry {
  id: number
  time: string
  level: "info" | "warn" | "alarm" | "ok"
  message: string
}

export interface EspState {
  mode: StationMode
  /** Whether the simulation/trains have been started by the operator. */
  running: boolean
  /** Whether a person is detected on the track (track circuit occupied). */
  occupancy: Record<TrackId, TrackState>
  /** Whether the ESP system has tripped the track (protected). */
  espActive: Record<TrackId, boolean>
  /** Whether the train serving the track is commanded to a stop. */
  trainStopped: Record<TrackId, boolean>
  /** Cruise speed of each train, in km/h. */
  trainSpeedKmh: Record<TrackId, number>
  /** Global station emergency banner. */
  emergency: boolean
  /** Increments every RESET — lets components (e.g. a stopped train) detect
   *  a reset even when their other props haven't meaningfully changed, so
   *  they can restart their own internal cycle instead of idling. */
  resetCount: number
  log: LogEntry[]
}

type Action =
  | { type: "SET_MODE"; mode: StationMode }
  | { type: "START" }
  | { type: "STOP" }
  | { type: "PERSON_FALL"; track: TrackId }
  | { type: "EMERGENCY_BRAKE"; track: TrackId }
  | { type: "SET_SPEED"; track: TrackId; speedKmh: number }
  | { type: "RESET" }

/**
 * Emergency-brake deceleration used across the simulator, in m/s².
 * 1.3 m/s² (~0.13 g) is a typical metro emergency-brake rate and reproduces
 * the reference figures: 50 km/h → 10.7 s / 74 m, 60 km/h → 12.8 s / 107 m.
 */
export const EB_DECEL_MS2 = 1.3

/** Physical stopping time (s) & distance (m) for a given cruise speed (km/h). */
export function brakingProfile(speedKmh: number) {
  const v = speedKmh / 3.6 // m/s
  const stopTime = v / EB_DECEL_MS2
  const stopDist = (v * v) / (2 * EB_DECEL_MS2)
  return { stopTime, stopDist }
}

const MAX_LOG = 60
let logCounter = 0

function now() {
  const d = new Date()
  return d.toLocaleTimeString("en-GB", { hour12: false }) + "." + String(d.getMilliseconds()).padStart(3, "0")
}

function log(level: LogEntry["level"], message: string): LogEntry {
  logCounter += 1
  return { id: logCounter, time: now(), level, message }
}

function cleanState(mode: StationMode, resetCount = 0): EspState {
  return {
    mode,
    running: true,
    occupancy: { A: "clear", B: "clear" },
    espActive: { A: false, B: false },
    trainStopped: { A: false, B: false },
    trainSpeedKmh: { A: 60, B: 60 },
    emergency: false,
    resetCount,
    log: [
      log("ok", `${mode === "elevated" ? "ELEVATED" : "UNDERGROUND"} station ESP armed`),
      log("info", "Track circuits A & B: CLEAR · Trains running"),
    ],
  }
}

function reducer(state: EspState, action: Action): EspState {
  switch (action.type) {
    case "SET_MODE":
      if (action.mode === state.mode) return state
      return cleanState(action.mode)

    case "START": {
      if (state.running) return state
      return {
        ...state,
        running: true,
        log: [log("ok", "Simulation STARTED · trains entering service"), ...state.log].slice(0, MAX_LOG),
      }
    }

    case "STOP": {
      if (!state.running) return state
      return {
        ...state,
        running: false,
        log: [log("info", "Simulation PAUSED · trains holding"), ...state.log].slice(0, MAX_LOG),
      }
    }

    case "EMERGENCY_BRAKE": {
      const t = action.track

      const profileLog = (id: TrackId): LogEntry => {
        const { stopTime, stopDist } = brakingProfile(state.trainSpeedKmh[id])
        return log(
          "warn",
          `Train ${id} @ ${state.trainSpeedKmh[id]} km/h · EB → stop in ${stopTime.toFixed(1)} s / ${stopDist.toFixed(0)} m`,
        )
      }

      if (state.mode === "elevated") {
        // Elevated shared guideway: the platforms sit either side of ONE
        // shared risk zone, so an E-brake on EITHER platform must stop BOTH
        // trains — neither service may pass the station.
        if (state.trainStopped.A && state.trainStopped.B) return state
        return {
          ...state,
          trainStopped: { A: true, B: true },
          trainSpeedKmh: { A: 0, B: 0 },
          emergency: true,
          log: [
            log("alarm", `EMERGENCY BRAKE applied on Platform ${t === "A" ? "1" : "2"}`),
            log("alarm", "Elevated shared zone — BOTH trains STOPPING"),
            profileLog("A"),
            profileLog("B"),
            ...state.log,
          ].slice(0, MAX_LOG),
        }
      }

      // underground: tunnels are isolated, only the braked train stops.
      if (state.trainStopped[t]) return state
      return {
        ...state,
        trainStopped: { ...state.trainStopped, [t]: true },
        trainSpeedKmh: { ...state.trainSpeedKmh, [t]: 0 },
        emergency: true,
        log: [
          log("alarm", `Manual EMERGENCY BRAKE applied · Train ${t} STOPPING`),
          profileLog(t),
          ...state.log,
        ].slice(0, MAX_LOG),
      }
    }

    case "SET_SPEED": {
      if (state.trainStopped[action.track]) return state
      const clamped = Math.max(20, Math.min(90, Math.round(action.speedKmh)))
      if (clamped === state.trainSpeedKmh[action.track]) return state
      return {
        ...state,
        trainSpeedKmh: { ...state.trainSpeedKmh, [action.track]: clamped },
        log: [
          log("info", `Train ${action.track} cruise speed set to ${clamped} km/h`),
          ...state.log,
        ].slice(0, MAX_LOG),
      }
    }

    case "RESET": {
      const base = cleanState(state.mode, state.resetCount + 1)
      return {
        ...base,
        trainSpeedKmh: state.trainSpeedKmh,
        log: [log("ok", "ESP reset · System restored to normal operation"), ...base.log],
      }
    }

    case "PERSON_FALL": {
      const t = action.track
      if (state.occupancy[t] === "occupied") return state

      const other: TrackId = t === "A" ? "B" : "A"
      const entries: LogEntry[] = [
        log("alarm", `INTRUSION on Track ${t} · Track circuit OCCUPIED`),
      ]

      if (state.mode === "elevated") {
        // Shared risk zone: ESP raises the alert on both tracks. Trains keep
        // running until a controller presses the EMERGENCY BRAKE.
        entries.push(
          log("warn", "Shared guideway — ESP ALERT raised on BOTH tracks"),
          log("warn", "Trains STILL RUNNING — press EMERGENCY BRAKE to stop"),
        )
        return {
          ...state,
          occupancy: { ...state.occupancy, [t]: "occupied" },
          espActive: { A: true, B: true },
          emergency: true,
          log: [...entries, ...state.log].slice(0, MAX_LOG),
        }
      }

      // underground: tunnels are physically isolated — only the affected tunnel is alerted.
      entries.push(
        log("warn", `Tunnel ${t} isolated — ESP ALERT on Track ${t} ONLY`),
        log("warn", `Train ${t} STILL RUNNING — press EMERGENCY BRAKE to stop`),
        log("ok", `Tunnel ${other} unaffected · Train ${other} continues normal service`),
      )
      return {
        ...state,
        occupancy: { ...state.occupancy, [t]: "occupied" },
        espActive: { ...state.espActive, [t]: true },
        emergency: true,
        log: [...entries, ...state.log].slice(0, MAX_LOG),
      }
    }

    default:
      return state
  }
}

interface EspContextValue extends EspState {
  setMode: (mode: StationMode) => void
  start: () => void
  stop: () => void
  personFall: (track: TrackId) => void
  emergencyBrake: (track: TrackId) => void
  setSpeed: (track: TrackId, speedKmh: number) => void
  reset: () => void
}

const EspContext = createContext<EspContextValue | null>(null)

export function EspProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, "underground", cleanState)

  const setMode = useCallback((mode: StationMode) => dispatch({ type: "SET_MODE", mode }), [])
  const start = useCallback(() => dispatch({ type: "START" }), [])
  const stop = useCallback(() => dispatch({ type: "STOP" }), [])
  const personFall = useCallback((track: TrackId) => dispatch({ type: "PERSON_FALL", track }), [])
  const emergencyBrake = useCallback((track: TrackId) => dispatch({ type: "EMERGENCY_BRAKE", track }), [])
  const setSpeed = useCallback(
    (track: TrackId, speedKmh: number) => dispatch({ type: "SET_SPEED", track, speedKmh }),
    [],
  )
  const reset = useCallback(() => dispatch({ type: "RESET" }), [])

  return (
    <EspContext.Provider value={{ ...state, setMode, start, stop, personFall, emergencyBrake, setSpeed, reset }}>
      {children}
    </EspContext.Provider>
  )
}

export function useEsp() {
  const ctx = useContext(EspContext)
  if (!ctx) throw new Error("useEsp must be used within EspProvider")
  return ctx
}
