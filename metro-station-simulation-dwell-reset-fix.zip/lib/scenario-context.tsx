"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import type { TrackId } from "./esp-store"

export type ScenarioType = "person-fall" | "object-fall" | "train-start"

interface ScenarioContextType {
  /** Currently selected scenario */
  selectedScenario: { type: ScenarioType; platform: TrackId } | null
  /** Whether a scenario is currently playing */
  scenarioActive: boolean
  /** Timestamp when scenario started (for animations) */
  scenarioStartTime: number
  /** Set the selected scenario */
  selectScenario: (type: ScenarioType, platform: TrackId) => void
  /** Start the selected scenario */
  startScenario: () => void
  /** Select AND immediately start a scenario in a single atomic action (avoids
   *  the stale-closure issue of calling selectScenario + startScenario back to back). */
  triggerScenario: (type: ScenarioType, platform: TrackId) => void
  /** Stop/reset the current scenario */
  stopScenario: () => void
  /** Check if a specific scenario is selected */
  isScenarioSelected: (type: ScenarioType, platform: TrackId) => boolean
}

const ScenarioContext = createContext<ScenarioContextType | undefined>(undefined)

export function ScenarioProvider({ children }: { children: ReactNode }) {
  const [selectedScenario, setSelectedScenario] = useState<{ type: ScenarioType; platform: TrackId } | null>(null)
  const [scenarioActive, setScenarioActive] = useState(false)
  const [scenarioStartTime, setScenarioStartTime] = useState(0)

  const selectScenario = useCallback((type: ScenarioType, platform: TrackId) => {
    setSelectedScenario({ type, platform })
    setScenarioActive(false)
  }, [])

  const startScenario = useCallback(() => {
    if (selectedScenario) {
      setScenarioActive(true)
      setScenarioStartTime(typeof performance !== "undefined" ? performance.now() : Date.now())
    }
  }, [selectedScenario])

  const triggerScenario = useCallback((type: ScenarioType, platform: TrackId) => {
    // Set selection + active state together in one go, so a single click
    // both highlights the button AND fires the incident immediately.
    setSelectedScenario({ type, platform })
    setScenarioActive(true)
    setScenarioStartTime(typeof performance !== "undefined" ? performance.now() : Date.now())
  }, [])

  const stopScenario = useCallback(() => {
    setScenarioActive(false)
    setSelectedScenario(null)
    setScenarioStartTime(0)
  }, [])

  const isScenarioSelected = useCallback(
    (type: ScenarioType, platform: TrackId) => 
      selectedScenario?.type === type && selectedScenario?.platform === platform,
    [selectedScenario]
  )

  return (
    <ScenarioContext.Provider
      value={{
        selectedScenario,
        scenarioActive,
        scenarioStartTime,
        selectScenario,
        startScenario,
        triggerScenario,
        stopScenario,
        isScenarioSelected,
      }}
    >
      {children}
    </ScenarioContext.Provider>
  )
}

export function useScenario() {
  const context = useContext(ScenarioContext)
  if (!context) {
    throw new Error("useScenario must be used within ScenarioProvider")
  }
  return context
}
