"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import type { TrackId } from "./esp-store"

interface PlatformESPContextType {
  /** Which platform ESP plungers have been pressed (latched until reset). */
  espPressed: Record<TrackId, boolean>
  /** Convenience flag — true when any ESP is active. */
  anyPressed: boolean
  triggerPlatformESP: (platform: TrackId) => void
  clearPlatformESP: () => void
}

const PlatformESPContext = createContext<PlatformESPContextType | undefined>(undefined)

export function PlatformESPProvider({ children }: { children: ReactNode }) {
  const [espPressed, setEspPressed] = useState<Record<TrackId, boolean>>({ A: false, B: false })

  const triggerPlatformESP = useCallback((platform: TrackId) => {
    // Latch the pressed state so the SCR alarm stays lit until reset.
    setEspPressed((prev) => ({ ...prev, [platform]: true }))
  }, [])

  const clearPlatformESP = useCallback(() => {
    setEspPressed({ A: false, B: false })
  }, [])

  const anyPressed = espPressed.A || espPressed.B

  return (
    <PlatformESPContext.Provider value={{ espPressed, anyPressed, triggerPlatformESP, clearPlatformESP }}>
      {children}
    </PlatformESPContext.Provider>
  )
}

export function usePlatformESP() {
  const context = useContext(PlatformESPContext)
  if (!context) {
    throw new Error("usePlatformESP must be used within PlatformESPProvider")
  }
  return context
}
