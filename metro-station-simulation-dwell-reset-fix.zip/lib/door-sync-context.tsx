"use client"

import { createContext, useCallback, useContext, ReactNode, useState } from "react"

interface DoorSyncState {
  trainDoorOpenA: number // 0 to 1
  trainDoorOpenB: number // 0 to 1
  psdOpenA: number // 0 to 1
  psdOpenB: number // 0 to 1
  barrierOpenA: number // 0 to 1 — barrier gate open state
  barrierOpenB: number // 0 to 1
  trainPhaseA: "arriving" | "dwell" | "leaving" | "idle"
  trainPhaseB: "arriving" | "dwell" | "leaving" | "idle"
  statusMessageA: string
  statusMessageB: string
}

interface DoorSyncContextType {
  state: DoorSyncState
  updateTrainDoor: (track: "A" | "B", openAmount: number) => void
  updateTrainPhase: (track: "A" | "B", phase: "arriving" | "dwell" | "leaving" | "idle") => void
}

const DoorSyncContext = createContext<DoorSyncContextType | undefined>(undefined)

export function DoorSyncProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DoorSyncState>({
    trainDoorOpenA: 0,
    trainDoorOpenB: 0,
    psdOpenA: 0,
    psdOpenB: 0,
    barrierOpenA: 0,
    barrierOpenB: 0,
    trainPhaseA: "idle",
    trainPhaseB: "idle",
    statusMessageA: "Idle",
    statusMessageB: "Idle",
  })

  const updateTrainDoor = useCallback((track: "A" | "B", openAmount: number) => {
    setState((prev) => ({
      ...prev,
      [track === "A" ? "trainDoorOpenA" : "trainDoorOpenB"]: openAmount,
      [track === "A" ? "psdOpenA" : "psdOpenB"]:
        prev[track === "A" ? "trainPhaseA" : "trainPhaseB"] === "dwell" ? openAmount : 0,
      [track === "A" ? "barrierOpenA" : "barrierOpenB"]:
        prev[track === "A" ? "trainPhaseA" : "trainPhaseB"] === "dwell" ? openAmount : 0,
      [track === "A" ? "statusMessageA" : "statusMessageB"]: getStatusMessage(
        prev[track === "A" ? "trainPhaseA" : "trainPhaseB"],
        openAmount,
      ),
    }))
  }, [])

  const updateTrainPhase = useCallback((track: "A" | "B", phase: "arriving" | "dwell" | "leaving" | "idle") => {
    setState((prev) => ({
      ...prev,
      [track === "A" ? "trainPhaseA" : "trainPhaseB"]: phase,
      [track === "A" ? "psdOpenA" : "psdOpenB"]:
        phase === "dwell" ? prev[track === "A" ? "trainDoorOpenA" : "trainDoorOpenB"] : 0,
      [track === "A" ? "barrierOpenA" : "barrierOpenB"]:
        phase === "dwell" ? prev[track === "A" ? "trainDoorOpenA" : "trainDoorOpenB"] : 0,
      [track === "A" ? "statusMessageA" : "statusMessageB"]: getStatusMessage(
        phase,
        prev[track === "A" ? "trainDoorOpenA" : "trainDoorOpenB"],
      ),
    }))
  }, [])

  return (
    <DoorSyncContext.Provider value={{ state, updateTrainDoor, updateTrainPhase }}>
      {children}
    </DoorSyncContext.Provider>
  )
}

export function useDoorSync() {
  const context = useContext(DoorSyncContext)
  if (!context) {
    throw new Error("useDoorSync must be used within DoorSyncProvider")
  }
  return context
}

function getStatusMessage(phase: string, doorOpen: number): string {
  if (phase === "arriving") return "Train Approaching"
  if (phase === "dwell") {
    if (doorOpen < 0.1) return "Opening Doors..."
    if (doorOpen < 0.9) return "Boarding Passengers"
    return "Doors Open - Boarding"
  }
  if (phase === "leaving") {
    if (doorOpen > 0.1) return "Closing Doors..."
    return "Train Ready to Depart"
  }
  return "Idle"
}
