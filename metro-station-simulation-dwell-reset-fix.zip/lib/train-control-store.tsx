"use client"

import {
  createContext,
  useContext,
  useEffect,
  useReducer,
  useRef,
  useCallback,
  type ReactNode,
} from "react"

/* ----------------------------------------------------------------------------
 * Metro Train Control Simulation Engine
 * Modes: ATO (Automatic Train Operation), RM (Restricted Manual), EMERGENCY.
 * ATP (Automatic Train Protection) supervises speed in ALL modes.
 * ATO Cutout isolates ATO and hands over to RM without stopping the train.
 * -------------------------------------------------------------------------- */

export type Mode = "ATO" | "RM" | "EMERGENCY"
export type AtoStatus = "ACTIVE" | "STANDBY" | "FAILED" | "CUTOUT"
export type AtpStatus = "SUPERVISING" | "OVERSPEED" | "INTERVENING"
export type DoorState = "CLOSED" | "OPENING" | "OPEN" | "CLOSING"
export type Throttle = "COAST" | "POWER" | "BRAKE"
export type EventLevel = "info" | "ok" | "warn" | "alarm"

export interface SimEvent {
  id: number
  t: number // simulation clock seconds
  wall: number // wall-clock ms (for timestamp)
  trainId: string
  type: string
  message: string
  level: EventLevel
  fromMode?: Mode
  toMode?: Mode
  reason?: string
}

export interface Station {
  name: string
  position: number // meters along the line
}

export interface SimState {
  trainId: string
  running: boolean
  serviceStarted: boolean
  clock: number // sim seconds elapsed
  mode: Mode
  speed: number // current km/h
  targetSpeed: number // commanded km/h
  position: number // meters along line (wraps at LINE_LENGTH)
  ato: AtoStatus
  atp: AtpStatus
  permittedSpeed: number // current ATP ceiling km/h
  authority: number // meters of movement authority ahead
  doors: DoorState
  doorTimer: number
  dwellTimer: number
  throttle: Throttle // RM operator demand
  atStation: boolean
  nextStationIndex: number
  overspeedActive: boolean
  log: SimEvent[]
}

/* --- line / physics constants --------------------------------------------- */
export const STATIONS: Station[] = [
  { name: "Central", position: 600 },
  { name: "Riverside", position: 1800 },
  { name: "Junction", position: 3000 },
  { name: "Parkway", position: 4200 },
  { name: "Terminus", position: 5400 },
]
export const LINE_LENGTH = 6000
export const LINE_MAX_SPEED = 70 // km/h ATP ceiling on open line
export const RM_MAX_SPEED = 25 // km/h ATP ceiling in restricted manual
export const ATP_WARN_MARGIN = 1 // km/h above ceiling -> overspeed warning
export const ATP_TRIP_MARGIN = 6 // km/h above ceiling -> ATP emergency brake

const ACCEL = 0.9 // m/s^2 traction
const SERVICE_BRAKE = 1.1 // m/s^2 normal stop
const EMERGENCY_BRAKE = 1.3 // m/s^2 ATP / emergency
const RM_POWER_ACCEL = 0.8 // m/s^2 operator power
const DWELL_TIME = 4 // s doors-open dwell
const DOOR_TIME = 1.2 // s open/close transition
const MAX_LOG = 200

let EVENT_ID = 1

function mkEvent(
  state: SimState,
  level: EventLevel,
  type: string,
  message: string,
  extra?: Partial<SimEvent>,
): SimEvent {
  return {
    id: EVENT_ID++,
    t: state.clock,
    wall: Date.now(),
    trainId: state.trainId,
    type,
    message,
    level,
    ...extra,
  }
}

function pushLog(state: SimState, ev: SimEvent): SimEvent[] {
  return [ev, ...state.log].slice(0, MAX_LOG)
}

/* --- helpers --------------------------------------------------------------- */
const kmhToMps = (k: number) => k / 3.6
const mpsToKmh = (m: number) => m * 3.6

/** distance ahead to the next station, accounting for line wrap */
function distanceToStation(position: number, stationPos: number) {
  let d = stationPos - position
  if (d < -1) d += LINE_LENGTH
  return d
}

/* --------------------------------------------------------------------------- */
type Action =
  | { type: "TICK"; dt: number }
  | { type: "START_SERVICE" }
  | { type: "PAUSE" }
  | { type: "RESET" }
  | { type: "ATO_FAILURE" }
  | { type: "ATO_CUTOUT" }
  | { type: "RESTORE_ATO" }
  | { type: "SET_THROTTLE"; throttle: Throttle }
  | { type: "FORCE_EMERGENCY" }
  | { type: "EMERGENCY_RESET" }

function initialState(): SimState {
  return {
    trainId: "TR-204",
    running: false,
    serviceStarted: false,
    clock: 0,
    mode: "ATO",
    speed: 0,
    targetSpeed: 0,
    position: 0,
    ato: "STANDBY",
    atp: "SUPERVISING",
    permittedSpeed: LINE_MAX_SPEED,
    authority: STATIONS[0].position,
    doors: "CLOSED",
    doorTimer: 0,
    dwellTimer: 0,
    throttle: "COAST",
    atStation: false,
    nextStationIndex: 0,
    overspeedActive: false,
    log: [
      {
        id: EVENT_ID++,
        t: 0,
        wall: Date.now(),
        trainId: "TR-204",
        type: "SYSTEM",
        message: "Control system initialized · ATP armed · ATO standby",
        level: "info",
      },
    ],
  }
}

/* --- the simulation step --------------------------------------------------- */
function step(state: SimState, dt: number): SimState {
  if (!state.running || !state.serviceStarted) return state

  let s: SimState = { ...state, clock: state.clock + dt }
  let log = s.log

  // ATP permitted ceiling depends on mode
  const ceiling = s.mode === "RM" ? RM_MAX_SPEED : LINE_MAX_SPEED
  s.permittedSpeed = ceiling

  const station = STATIONS[s.nextStationIndex]
  const distToStation = distanceToStation(s.position, station.position)
  s.authority = Math.max(0, distToStation)

  /* ---- determine target speed by mode ---- */
  let target = s.targetSpeed
  const vMps = kmhToMps(s.speed)

  if (s.mode === "ATO") {
    // automatic driving profile
    if (s.doors !== "CLOSED") {
      target = 0 // hold while doors are not secured
    } else if (s.atStation) {
      target = 0
    } else {
      const brakeDist = (vMps * vMps) / (2 * SERVICE_BRAKE) + 8
      if (distToStation <= brakeDist) {
        target = 0 // brake into the station
      } else {
        target = Math.min(LINE_MAX_SPEED, 65)
      }
    }
  } else if (s.mode === "RM") {
    // operator demand via throttle
    if (s.throttle === "POWER") {
      // operator may push past the RM ceiling -> ATP will react
      target = Math.min(s.speed + 8, 34)
    } else if (s.throttle === "BRAKE") {
      target = 0
    } else {
      target = s.speed // coast: hold current
    }
  } else {
    // EMERGENCY
    target = 0
  }
  s.targetSpeed = Math.round(target)

  /* ---- ATP supervision (all modes) ---- */
  const overByTrip = s.speed > ceiling + ATP_TRIP_MARGIN
  const overByWarn = s.speed > ceiling + ATP_WARN_MARGIN

  if (overByTrip && s.mode !== "EMERGENCY") {
    // critical violation -> ATP emergency brake intervention
    const from = s.mode
    s.mode = "EMERGENCY"
    s.atp = "INTERVENING"
    s.throttle = "COAST"
    log = pushLog(
      { ...s, log },
      mkEvent({ ...s, log }, "alarm", "ATP_EMERGENCY", `ATP EMERGENCY BRAKE · overspeed ${s.speed.toFixed(0)} > ${ceiling} km/h`, {
        fromMode: from,
        toMode: "EMERGENCY",
        reason: "ATP critical speed violation",
      }),
    )
  } else if (overByWarn && s.mode !== "EMERGENCY") {
    if (!s.overspeedActive) {
      s.overspeedActive = true
      s.atp = "OVERSPEED"
      log = pushLog(
        { ...s, log },
        mkEvent({ ...s, log }, "warn", "ATP_OVERSPEED", `ATP overspeed warning · ${s.speed.toFixed(0)} km/h (limit ${ceiling})`),
      )
    }
  } else if (s.mode !== "EMERGENCY") {
    if (s.overspeedActive) {
      s.overspeedActive = false
    }
    s.atp = "SUPERVISING"
  }

  /* ---- longitudinal dynamics ---- */
  let accelMps: number
  if (s.mode === "EMERGENCY") {
    accelMps = -EMERGENCY_BRAKE
  } else if (s.speed < s.targetSpeed - 0.2) {
    accelMps = s.mode === "RM" ? RM_POWER_ACCEL : ACCEL
  } else if (s.speed > s.targetSpeed + 0.2) {
    // braking: harder if ATP is supervising an overspeed
    accelMps = -(s.atp === "OVERSPEED" ? EMERGENCY_BRAKE : SERVICE_BRAKE)
  } else {
    accelMps = 0
  }

  let newSpeed = s.speed + mpsToKmh(accelMps) * dt
  if (newSpeed < 0) newSpeed = 0
  if (accelMps === 0) newSpeed = s.targetSpeed
  s.speed = newSpeed

  // advance position
  s.position = s.position + kmhToMps(s.speed) * dt
  if (s.position >= LINE_LENGTH) {
    s.position -= LINE_LENGTH
  }

  /* ---- station / door sequencing (ATO only) ---- */
  if (s.mode === "ATO") {
    const dist = distanceToStation(s.position, station.position)
    if (!s.atStation && dist < 6 && s.speed < 1.2) {
      s.speed = 0
      s.atStation = true
      s.doors = "OPENING"
      s.doorTimer = DOOR_TIME
      log = pushLog(
        { ...s, log },
        mkEvent({ ...s, log }, "ok", "ENTER_STATION", `Arrived at ${station.name} · opening doors`),
      )
    }

    if (s.atStation) {
      if (s.doors === "OPENING") {
        s.doorTimer -= dt
        if (s.doorTimer <= 0) {
          s.doors = "OPEN"
          s.dwellTimer = DWELL_TIME
          log = pushLog({ ...s, log }, mkEvent({ ...s, log }, "info", "DOORS_OPEN", `Doors open at ${station.name}`))
        }
      } else if (s.doors === "OPEN") {
        s.dwellTimer -= dt
        if (s.dwellTimer <= 0) {
          s.doors = "CLOSING"
          s.doorTimer = DOOR_TIME
          log = pushLog({ ...s, log }, mkEvent({ ...s, log }, "info", "DOORS_CLOSE", `Closing doors at ${station.name}`))
        }
      } else if (s.doors === "CLOSING") {
        s.doorTimer -= dt
        if (s.doorTimer <= 0) {
          s.doors = "CLOSED"
          s.atStation = false
          const departed = station.name
          const nextIdx = (s.nextStationIndex + 1) % STATIONS.length
          s.nextStationIndex = nextIdx
          if (nextIdx === 0) {
            s.position = 0 // loop service from start of line
          }
          log = pushLog(
            { ...s, log },
            mkEvent({ ...s, log }, "ok", "LEAVE_STATION", `Departing ${departed} · next stop ${STATIONS[nextIdx].name}`),
          )
        }
      }
    }
  }

  /* ---- emergency auto-clear bookkeeping ---- */
  if (s.mode === "EMERGENCY" && s.speed <= 0.05) {
    s.speed = 0
  }

  s.log = log
  return s
}

/* --- reducer for discrete operator/system actions -------------------------- */
function reducer(state: SimState, action: Action): SimState {
  switch (action.type) {
    case "TICK":
      return step(state, action.dt)

    case "START_SERVICE": {
      if (state.serviceStarted) {
        // resume
        return { ...state, running: true }
      }
      const s: SimState = {
        ...state,
        serviceStarted: true,
        running: true,
        mode: "ATO",
        ato: "ACTIVE",
        atp: "SUPERVISING",
      }
      return {
        ...s,
        log: pushLog(s, mkEvent(s, "ok", "START_SERVICE", "Service started · ATO engaged · doors closed", {
          toMode: "ATO",
        })),
      }
    }

    case "PAUSE":
      return { ...state, running: false }

    case "RESET": {
      const fresh = initialState()
      return fresh
    }

    case "ATO_FAILURE": {
      if (state.ato === "FAILED" || state.ato === "CUTOUT") return state
      const s = { ...state, ato: "FAILED" as AtoStatus }
      return {
        ...s,
        log: pushLog(
          s,
          mkEvent(s, "alarm", "ATO_FAILURE", "ATO failure detected · automatic driving degraded · ATP still active", {
            reason: "ATO subsystem fault",
          }),
        ),
      }
    }

    case "ATO_CUTOUT": {
      if (state.mode === "EMERGENCY") return state
      if (state.ato === "CUTOUT") return state
      // isolate ATO, hand over to RM WITHOUT stopping
      const from = state.mode
      const s: SimState = {
        ...state,
        ato: "CUTOUT",
        mode: "RM",
        throttle: "COAST",
        atStation: false,
        doors: state.doors === "CLOSED" ? "CLOSED" : state.doors,
      }
      return {
        ...s,
        log: pushLog(
          s,
          mkEvent(s, "warn", "ATO_CUTOUT", "ATO CUTOUT activated · ATO isolated · transition ATO → RM · operator in control", {
            fromMode: from,
            toMode: "RM",
            reason: "ATO Cutout",
          }),
        ),
      }
    }

    case "RESTORE_ATO": {
      // RM -> ATO only when ATO healthy, ATP authorization available, operator requests
      if (state.mode !== "RM") return state
      if (state.atp === "INTERVENING") return state
      const s: SimState = {
        ...state,
        ato: "ACTIVE",
        mode: "ATO",
        throttle: "COAST",
      }
      return {
        ...s,
        log: pushLog(
          s,
          mkEvent(s, "ok", "RESTORE_ATO", "ATO restored · ATP authorization confirmed · transition RM → ATO", {
            fromMode: "RM",
            toMode: "ATO",
            reason: "Operator requested ATO restore",
          }),
        ),
      }
    }

    case "SET_THROTTLE": {
      if (state.mode !== "RM") return state
      if (state.throttle === action.throttle) return state
      const s = { ...state, throttle: action.throttle }
      const label = action.throttle === "POWER" ? "POWER" : action.throttle === "BRAKE" ? "BRAKE" : "COAST"
      return {
        ...s,
        log: pushLog(s, mkEvent(s, "info", "RM_CONTROL", `RM operator: ${label}`)),
      }
    }

    case "FORCE_EMERGENCY": {
      if (state.mode === "EMERGENCY") return state
      const from = state.mode
      const s: SimState = { ...state, mode: "EMERGENCY", atp: "INTERVENING", throttle: "COAST" }
      return {
        ...s,
        log: pushLog(
          s,
          mkEvent(s, "alarm", "EMERGENCY", "Emergency brake commanded", {
            fromMode: from,
            toMode: "EMERGENCY",
            reason: "Manual emergency",
          }),
        ),
      }
    }

    case "EMERGENCY_RESET": {
      if (state.mode !== "EMERGENCY") return state
      if (state.speed > 0.5) return state // must be stopped
      const s: SimState = {
        ...state,
        mode: "RM",
        atp: "SUPERVISING",
        ato: state.ato === "CUTOUT" ? "CUTOUT" : state.ato === "FAILED" ? "FAILED" : "STANDBY",
        overspeedActive: false,
        throttle: "COAST",
      }
      return {
        ...s,
        log: pushLog(
          s,
          mkEvent(s, "ok", "EMERGENCY_RESET", "Emergency reset · brakes released · RM available", {
            fromMode: "EMERGENCY",
            toMode: "RM",
          }),
        ),
      }
    }

    default:
      return state
  }
}

/* --- context + provider ---------------------------------------------------- */
interface ContextValue extends SimState {
  startService: () => void
  pause: () => void
  reset: () => void
  atoFailure: () => void
  atoCutout: () => void
  restoreAto: () => void
  setThrottle: (t: Throttle) => void
  forceEmergency: () => void
  emergencyReset: () => void
}

const Ctx = createContext<ContextValue | null>(null)

export function TrainControlProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, initialState)
  const runningRef = useRef(state.running)
  runningRef.current = state.running

  // fixed-step simulation loop (10 Hz)
  useEffect(() => {
    const DT = 0.1
    const id = setInterval(() => {
      if (runningRef.current) dispatch({ type: "TICK", dt: DT })
    }, 100)
    return () => clearInterval(id)
  }, [])

  const startService = useCallback(() => dispatch({ type: "START_SERVICE" }), [])
  const pause = useCallback(() => dispatch({ type: "PAUSE" }), [])
  const reset = useCallback(() => dispatch({ type: "RESET" }), [])
  const atoFailure = useCallback(() => dispatch({ type: "ATO_FAILURE" }), [])
  const atoCutout = useCallback(() => dispatch({ type: "ATO_CUTOUT" }), [])
  const restoreAto = useCallback(() => dispatch({ type: "RESTORE_ATO" }), [])
  const setThrottle = useCallback((t: Throttle) => dispatch({ type: "SET_THROTTLE", throttle: t }), [])
  const forceEmergency = useCallback(() => dispatch({ type: "FORCE_EMERGENCY" }), [])
  const emergencyReset = useCallback(() => dispatch({ type: "EMERGENCY_RESET" }), [])

  return (
    <Ctx.Provider
      value={{
        ...state,
        startService,
        pause,
        reset,
        atoFailure,
        atoCutout,
        restoreAto,
        setThrottle,
        forceEmergency,
        emergencyReset,
      }}
    >
      {children}
    </Ctx.Provider>
  )
}

export function useTrainControl() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error("useTrainControl must be used within TrainControlProvider")
  return ctx
}

/* --- formatting helpers shared by UI --------------------------------------- */
export function formatClock(wall: number) {
  const d = new Date(wall)
  return d.toLocaleTimeString("en-GB", { hour12: false }) + "." + String(d.getMilliseconds()).padStart(3, "0").slice(0, 2)
}

/** Deterministic mission-clock formatter (server/client safe). t = sim seconds. */
export function formatSimClock(t: number) {
  const total = Math.max(0, t)
  const mm = Math.floor(total / 60)
  const ss = Math.floor(total % 60)
  const ds = Math.floor((total - Math.floor(total)) * 10)
  return `T+${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}.${ds}`
}
