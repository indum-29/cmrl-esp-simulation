"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import type { TrackId } from "./esp-store"

export type FallKind = "person" | "object" | "both"

interface FallingPersonContextType {
  /** Whether a person/object hazard has fallen onto each track. */
  fallen: Record<TrackId, boolean>
  /** performance.now() timestamp when the fall was triggered (drives the 3D animation). 0 = none. */
  fallStart: Record<TrackId, number>
  /** Which hazard type is currently on each track — determines what the 3D scene renders. */
  fallKind: Record<TrackId, FallKind>
  triggerFall: (track: TrackId, kind?: FallKind) => void
  clearFalls: () => void
}

const FallingPersonContext = createContext<FallingPersonContextType | undefined>(undefined)

export function FallingPersonProvider({ children }: { children: ReactNode }) {
  const [fallen, setFallen] = useState<Record<TrackId, boolean>>({ A: false, B: false })
  const [fallStart, setFallStart] = useState<Record<TrackId, number>>({ A: 0, B: 0 })
  const [fallKind, setFallKind] = useState<Record<TrackId, FallKind>>({ A: "both", B: "both" })

  const triggerFall = useCallback((track: TrackId, kind: FallKind = "both") => {
    const now = typeof performance !== "undefined" ? performance.now() : Date.now()
    // The hazard persists on the track until it is explicitly reset.
    setFallStart((prev) => ({ ...prev, [track]: now }))
    setFallen((prev) => ({ ...prev, [track]: true }))
    setFallKind((prev) => ({ ...prev, [track]: kind }))
  }, [])

  const clearFalls = useCallback(() => {
    setFallen({ A: false, B: false })
    setFallStart({ A: 0, B: 0 })
    setFallKind({ A: "both", B: "both" })
  }, [])

  return (
    <FallingPersonContext.Provider value={{ fallen, fallStart, fallKind, triggerFall, clearFalls }}>
      {children}
    </FallingPersonContext.Provider>
  )
}

export function useFallingPerson() {
  const context = useContext(FallingPersonContext)
  if (!context) {
    throw new Error("useFallingPerson must be used within FallingPersonProvider")
  }
  return context
}
