import { useEffect, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

interface FallingPersonProps {
  platform: number
}

export function FallingPerson({ platform }: FallingPersonProps) {
  const groupRef = useRef<THREE.Group>(null)
  const startTime = useRef(Date.now())
  const hasLanded = useRef(false)

  // Platform 1 is on the left (-8), Platform 2 is on the right (8)
  const platformX = platform === 1 ? -8 : 8
  const platformZ = platform === 1 ? -5 : 5

  useEffect(() => {
    startTime.current = Date.now()
    hasLanded.current = false
  }, [platform])

  useFrame(() => {
    if (!groupRef.current) return

    const elapsed = (Date.now() - startTime.current) / 1000
    const fallDuration = 2.0

    if (elapsed < fallDuration) {
      // Falling animation
      const progress = elapsed / fallDuration
      
      // Start from platform edge and fall to track
      const startY = 1.5 // Platform height
      const endY = -1.2 // Track level
      const currentY = startY - (startY - endY) * progress

      // Move toward center of track
      const trackX = platformX > 0 ? 2.5 : -2.5
      const currentX = platformX + (trackX - platformX) * progress

      groupRef.current.position.set(currentX, currentY, platformZ)

      // Add rotation as falling
      groupRef.current.rotation.x = progress * Math.PI * 0.5
      groupRef.current.rotation.z = progress * Math.PI * 0.3

      hasLanded.current = false
    } else {
      // Landed on track
      const trackX = platformX > 0 ? 2.5 : -2.5
      groupRef.current.position.set(trackX, -1.2, platformZ)
      groupRef.current.rotation.set(0, 0, 0)
      hasLanded.current = true
    }
  })

  return (
    <group ref={groupRef} position={[platformX, 1.5, platformZ]}>
      {/* Head */}
      <mesh position={[0, 0.5, 0]} castShadow>
        <sphereGeometry args={[0.25, 8, 8]} />
        <meshStandardMaterial color="#f4a460" emissive="#ff8c42" emissiveIntensity={0.2} />
      </mesh>

      {/* Body */}
      <mesh position={[0, 0, 0]} castShadow>
        <capsuleGeometry args={[0.35, 0.9, 4, 8]} />
        <meshStandardMaterial color="#ff6b35" emissive="#ff5500" emissiveIntensity={0.3} />
      </mesh>

      {/* Left Arm */}
      <mesh position={[-0.5, 0.2, 0]} castShadow>
        <capsuleGeometry args={[0.12, 0.7, 3, 6]} />
        <meshStandardMaterial color="#f4a460" />
      </mesh>

      {/* Right Arm */}
      <mesh position={[0.5, 0.2, 0]} castShadow>
        <capsuleGeometry args={[0.12, 0.7, 3, 6]} />
        <meshStandardMaterial color="#f4a460" />
      </mesh>

      {/* Left Leg */}
      <mesh position={[-0.2, -0.7, 0]} castShadow>
        <capsuleGeometry args={[0.12, 0.8, 3, 6]} />
        <meshStandardMaterial color="#1f2937" />
      </mesh>

      {/* Right Leg */}
      <mesh position={[0.2, -0.7, 0]} castShadow>
        <capsuleGeometry args={[0.12, 0.8, 3, 6]} />
        <meshStandardMaterial color="#1f2937" />
      </mesh>

      {/* Glow effect box around person to make them more visible */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[1.2, 1.5, 0.8]} />
        <meshStandardMaterial
          color="#ff6b35"
          transparent={true}
          opacity={0.1}
          emissive="#ff6b35"
          emissiveIntensity={0.4}
        />
      </mesh>
    </group>
  )
}
