"use client"

import { useState } from "react"
import { TrainControlProvider, useTrainControl, RM_MAX_SPEED } from "@/lib/train-control-store"
import { SpeedGauge } from "./speed-gauge"
import { StatusPanel } from "./status-panel"
import { ControlPanel } from "./control-panel"
import { EventLog } from "./event-log"
import { TrackView } from "./track-view"
import { Simulator } from "@/components/metro/simulator"
import { EspProvider, useEsp } from "@/lib/esp-store"
import { FallingPersonProvider } from "@/lib/falling-person-context"
import { PlatformESPProvider } from "@/lib/platform-esp-context"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <section className={cn("rounded-xl border border-border bg-card p-4 shadow-sm", className)}>{children}</section>
  )
}

function Header({ action }: { action?: React.ReactNode }) {
  const { trainId, clock, running, serviceStarted } = useTrainControl()
  const mm = Math.floor(clock / 60)
  const ss = Math.floor(clock % 60)
  const statusLabel = !serviceStarted ? "Standby" : running ? "Running" : "Paused"

  return (
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
      <div className="flex items-center gap-3">
        <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <span className="font-mono text-sm font-bold">M</span>
        </div>
        <div>
          <h1 className="font-mono text-base font-bold tracking-tight text-foreground">Metro Train Control Simulator</h1>
          <p className="font-mono text-[11px] text-muted-foreground">
            ATO · ATP · RM · ATO Cutout — Train {trainId}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="rounded-md border border-border bg-secondary/40 px-3 py-1.5 text-center">
          <p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Sim Clock</p>
          <p className="font-mono text-sm font-semibold tabular-nums text-foreground">
            {String(mm).padStart(2, "0")}:{String(ss).padStart(2, "0")}
          </p>
        </div>
        <div className="rounded-md border border-border bg-secondary/40 px-3 py-1.5 text-center">
          <p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Status</p>
          <p className="font-mono text-sm font-semibold text-foreground">{statusLabel}</p>
        </div>
        {action}
      </div>
    </header>
  )
}

function StationToggle() {
  const { mode, setMode } = useEsp()
  return (
    <div
      role="group"
      aria-label="Station type"
      className="flex items-center overflow-hidden rounded-md border border-border bg-secondary/40"
    >
      <button
        type="button"
        onClick={() => setMode("underground")}
        aria-pressed={mode === "underground"}
        className={cn(
          "px-3 py-2 font-mono text-[11px] font-semibold transition-colors",
          mode === "underground"
            ? "bg-primary text-primary-foreground"
            : "text-muted-foreground hover:text-foreground",
        )}
      >
        Underground
      </button>
      <button
        type="button"
        onClick={() => setMode("elevated")}
        aria-pressed={mode === "elevated"}
        className={cn(
          "px-3 py-2 font-mono text-[11px] font-semibold transition-colors",
          mode === "elevated"
            ? "bg-primary text-primary-foreground"
            : "text-muted-foreground hover:text-foreground",
        )}
      >
        Elevated
      </button>
    </div>
  )
}

function ControlToggle({ open, onClick }: { open: boolean; onClick: () => void }) {
  return (
    <Button
      onClick={onClick}
      aria-expanded={open}
      aria-controls="control-simulator"
      className="font-mono text-xs"
    >
      <span
        className={cn(
          "mr-2 inline-block size-2 rounded-full",
          open ? "bg-primary-foreground" : "bg-primary-foreground/60",
        )}
      />
      {open ? "Hide Control Simulator" : "Open Control Simulator"}
    </Button>
  )
}

function DashboardInner() {
  const [controlsOpen, setControlsOpen] = useState(false)

  return (
    <main className="relative h-screen w-full overflow-hidden bg-background">
      {/* Main view: 3D metro train simulation */}
      <Simulator />

      {/* Floating header overlay on top of the train */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-30 p-4">
        <div className="pointer-events-auto rounded-xl border border-border bg-card/85 px-4 py-3 shadow-lg backdrop-blur-md">
          <Header
            action={
              <>
                <StationToggle />
                <ControlToggle open={controlsOpen} onClick={() => setControlsOpen((v) => !v)} />
              </>
            }
          />
        </div>
      </div>

      {/* Slide-in control simulator at the side of the train */}
      <div
        aria-hidden={!controlsOpen}
        onClick={() => setControlsOpen(false)}
        className={cn(
          "fixed inset-0 z-40 bg-background/60 backdrop-blur-sm transition-opacity duration-300",
          controlsOpen ? "opacity-100" : "pointer-events-none opacity-0",
        )}
      />
      <aside
        id="control-simulator"
        className={cn(
          "fixed inset-y-0 right-0 z-50 flex w-[92%] max-w-md flex-col border-l border-border bg-card shadow-2xl transition-transform duration-300 ease-out",
          controlsOpen ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div>
            <p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Operator Console</p>
            <h2 className="font-mono text-sm font-bold text-foreground">Control Simulator</h2>
          </div>
          <Button
            onClick={() => setControlsOpen(false)}
            variant="ghost"
            size="icon"
            aria-label="Close control simulator"
            className="font-mono"
          >
            ✕
          </Button>
        </div>
        <div className="flex flex-1 flex-col gap-3 overflow-y-auto p-4">
          <Card className="flex flex-col items-center justify-center">
            <SpeedGauge />
          </Card>
          <Card>
            <StatusPanel />
          </Card>
          <Card>
            <ControlPanel />
          </Card>
          <Card>
            <TrackView />
          </Card>
          <Card className="max-h-72 overflow-hidden">
            <EventLog />
          </Card>
          <p className="text-pretty font-mono text-[10px] leading-relaxed text-muted-foreground">
            Scenario: start in ATO and let the train accelerate automatically. Simulate ATO failure, then activate ATO
            Cutout — the train transitions ATO → RM without stopping. Drive manually with Power/Coast/Brake while ATP
            keeps enforcing the {RM_MAX_SPEED} km/h RM ceiling and trips the emergency brake on critical overspeed.
          </p>
        </div>
      </aside>
    </main>
  )
}

export function Dashboard() {
  return (
    <PlatformESPProvider>
      <FallingPersonProvider>
        <EspProvider>
          <TrainControlProvider>
            <DashboardInner />
          </TrainControlProvider>
        </EspProvider>
      </FallingPersonProvider>
    </PlatformESPProvider>
  )
}
