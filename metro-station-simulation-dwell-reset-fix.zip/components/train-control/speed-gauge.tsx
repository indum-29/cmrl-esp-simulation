"use client"

import { useTrainControl, LINE_MAX_SPEED } from "@/lib/train-control-store"

const GAUGE_MAX = 80

export function SpeedGauge() {
  const { speed, targetSpeed, permittedSpeed, mode, atp } = useTrainControl()

  // semicircle gauge geometry
  const size = 240
  const cx = size / 2
  const cy = size / 2
  const r = 96
  const startAngle = 180
  const endAngle = 360

  const toXY = (angleDeg: number, radius: number) => {
    const a = (angleDeg * Math.PI) / 180
    return { x: cx + radius * Math.cos(a), y: cy + radius * Math.sin(a) }
  }
  const valueToAngle = (v: number) => startAngle + (Math.min(v, GAUGE_MAX) / GAUGE_MAX) * (endAngle - startAngle)

  const arcPath = (fromV: number, toV: number, radius: number) => {
    const a0 = valueToAngle(fromV)
    const a1 = valueToAngle(toV)
    const p0 = toXY(a0, radius)
    const p1 = toXY(a1, radius)
    const large = a1 - a0 > 180 ? 1 : 0
    return `M ${p0.x} ${p0.y} A ${radius} ${radius} 0 ${large} 1 ${p1.x} ${p1.y}`
  }

  const needleAngle = valueToAngle(speed)
  const needle = toXY(needleAngle, r - 14)

  const overLimit = speed > permittedSpeed + 1
  const speedColor =
    atp === "INTERVENING" || mode === "EMERGENCY"
      ? "var(--signal-alarm)"
      : overLimit
        ? "var(--signal-warn)"
        : "var(--signal-safe)"

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size / 2 + 30} viewBox={`0 0 ${size} ${size / 2 + 30}`} className="overflow-visible">
        {/* track arc */}
        <path d={arcPath(0, GAUGE_MAX, r)} fill="none" stroke="var(--border)" strokeWidth={14} strokeLinecap="round" />
        {/* permitted-speed zone marker (green up to ATP ceiling) */}
        <path
          d={arcPath(0, permittedSpeed, r)}
          fill="none"
          stroke="var(--signal-safe)"
          strokeOpacity={0.28}
          strokeWidth={14}
          strokeLinecap="round"
        />
        {/* live speed fill */}
        <path d={arcPath(0, speed, r)} fill="none" stroke={speedColor} strokeWidth={14} strokeLinecap="round" />
        {/* ATP ceiling tick */}
        {(() => {
          const a = valueToAngle(permittedSpeed)
          const inP = toXY(a, r - 10)
          const outP = toXY(a, r + 10)
          return <line x1={inP.x} y1={inP.y} x2={outP.x} y2={outP.y} stroke="var(--signal-warn)" strokeWidth={2.5} />
        })()}
        {/* target speed tick */}
        {(() => {
          const a = valueToAngle(targetSpeed)
          const inP = toXY(a, r - 10)
          const outP = toXY(a, r + 10)
          return <line x1={inP.x} y1={inP.y} x2={outP.x} y2={outP.y} stroke="var(--foreground)" strokeWidth={2} strokeDasharray="3 2" />
        })()}
        {/* needle */}
        <line x1={cx} y1={cy} x2={needle.x} y2={needle.y} stroke={speedColor} strokeWidth={3.5} strokeLinecap="round" />
        <circle cx={cx} cy={cy} r={6} fill={speedColor} />
      </svg>

      <div className="-mt-10 flex flex-col items-center">
        <span className="font-mono text-5xl font-bold tabular-nums tracking-tight" style={{ color: speedColor }}>
          {speed.toFixed(0)}
        </span>
        <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">km/h</span>
      </div>

      <div className="mt-3 grid w-full grid-cols-2 gap-2 text-center">
        <div className="rounded-md border border-border bg-secondary/40 px-2 py-1.5">
          <p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Target</p>
          <p className="font-mono text-sm font-semibold tabular-nums text-foreground">{targetSpeed} km/h</p>
        </div>
        <div className="rounded-md border border-border bg-secondary/40 px-2 py-1.5">
          <p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">ATP Limit</p>
          <p className="font-mono text-sm font-semibold tabular-nums text-signal-warn">{permittedSpeed} km/h</p>
        </div>
      </div>
      <p className="mt-2 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
        Line max {LINE_MAX_SPEED} km/h
      </p>
    </div>
  )
}
