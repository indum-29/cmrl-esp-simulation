"use client"

import { useTrainControl, STATIONS, LINE_LENGTH } from "@/lib/train-control-store"
import { cn } from "@/lib/utils"

export function TrackView() {
  const { position, nextStationIndex, mode, doors, atStation } = useTrainControl()

  const pct = (position / LINE_LENGTH) * 100

  const trainColor =
    mode === "EMERGENCY" ? "var(--signal-alarm)" : mode === "RM" ? "var(--signal-warn)" : "var(--signal-safe)"

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Line Position</p>
        <p className="font-mono text-[10px] tabular-nums text-muted-foreground">
          {Math.round(position)} m / {LINE_LENGTH} m
        </p>
      </div>

      <div className="relative mt-6 mb-2 h-2 rounded-full bg-secondary">
        {/* travelled fill */}
        <div
          className="absolute inset-y-0 left-0 rounded-full"
          style={{ width: `${pct}%`, backgroundColor: trainColor, opacity: 0.4 }}
        />

        {/* stations */}
        {STATIONS.map((st, i) => {
          const left = (st.position / LINE_LENGTH) * 100
          const isNext = i === nextStationIndex
          return (
            <div key={st.name} className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2" style={{ left: `${left}%` }}>
              <div
                className={cn(
                  "size-3 rounded-full border-2",
                  isNext ? "border-foreground bg-background" : "border-muted-foreground bg-muted",
                )}
              />
              <span
                className={cn(
                  "absolute left-1/2 top-4 -translate-x-1/2 whitespace-nowrap font-mono text-[9px] uppercase tracking-wide",
                  isNext ? "font-semibold text-foreground" : "text-muted-foreground",
                )}
              >
                {st.name}
              </span>
            </div>
          )
        })}

        {/* train marker */}
        <div
          className="absolute top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 transition-all duration-100 ease-linear"
          style={{ left: `${pct}%` }}
        >
          <div
            className="flex size-5 items-center justify-center rounded-sm shadow-md"
            style={{ backgroundColor: trainColor }}
            aria-label="train"
          >
            <span className="size-1.5 rounded-full bg-background" />
          </div>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between rounded-md border border-border bg-secondary/30 px-3 py-2">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Next Stop</span>
        <span className="font-mono text-xs font-semibold text-foreground">
          {STATIONS[nextStationIndex].name}
          {atStation && doors !== "CLOSED" ? " · at platform" : ""}
        </span>
      </div>
    </div>
  )
}
