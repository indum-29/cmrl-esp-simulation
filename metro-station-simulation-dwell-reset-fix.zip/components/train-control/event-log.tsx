"use client"

import { useTrainControl, formatSimClock, type EventLevel } from "@/lib/train-control-store"
import { cn } from "@/lib/utils"

const levelDot: Record<EventLevel, string> = {
  info: "bg-signal-info",
  ok: "bg-signal-safe",
  warn: "bg-signal-warn",
  alarm: "bg-signal-alarm",
}

export function EventLog() {
  const { log } = useTrainControl()

  return (
    <div className="flex h-full flex-col gap-3">
      <div className="flex items-center justify-between">
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Event Log</p>
        <span className="font-mono text-[10px] tabular-nums text-muted-foreground">{log.length} entries</span>
      </div>

      <ul className="flex max-h-[420px] flex-col gap-1 overflow-y-auto pr-1">
        {log.map((ev) => (
          <li
            key={ev.id}
            className="flex items-start gap-2 rounded-md border border-border/60 bg-secondary/20 px-2.5 py-1.5"
          >
            <span className={cn("mt-1 size-2 shrink-0 rounded-full", levelDot[ev.level])} />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-mono text-[10px] font-semibold uppercase tracking-wide text-foreground">
                  {ev.type}
                </span>
                <span className="shrink-0 font-mono text-[9px] tabular-nums text-muted-foreground">
                  {formatSimClock(ev.t)}
                </span>
              </div>
              <p className="font-mono text-[11px] leading-snug text-muted-foreground">{ev.message}</p>
              {(ev.fromMode || ev.toMode) && (
                <p className="mt-0.5 font-mono text-[9px] uppercase tracking-wide text-muted-foreground/70">
                  {ev.trainId}
                  {ev.fromMode ? ` · ${ev.fromMode} → ${ev.toMode}` : ` · ${ev.toMode}`}
                  {ev.reason ? ` · ${ev.reason}` : ""}
                </p>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
