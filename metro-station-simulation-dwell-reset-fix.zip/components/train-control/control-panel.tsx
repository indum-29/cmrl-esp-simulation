"use client"

import { useTrainControl } from "@/lib/train-control-store"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

function Section({
  title,
  hint,
  children,
}: {
  title: string
  hint?: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-col gap-0.5">
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{title}</p>
        {hint && <p className="text-[11px] leading-snug text-muted-foreground">{hint}</p>}
      </div>
      <div className="flex flex-col gap-2">{children}</div>
    </div>
  )
}

/** A small labelled button: bold action on top, plain-language description under it. */
function ActionButton({
  label,
  desc,
  ...props
}: { label: string; desc: string } & React.ComponentProps<typeof Button>) {
  return (
    <Button {...props} className={cn("h-auto flex-col items-start gap-0.5 py-2 text-left", props.className)}>
      <span className="font-mono text-xs font-semibold">{label}</span>
      <span className="text-[10px] font-normal leading-snug opacity-80">{desc}</span>
    </Button>
  )
}

/** Plain-language guidance telling the trainer exactly what to do next. */
function nextStepHint({
  serviceStarted,
  running,
  mode,
  ato,
}: {
  serviceStarted: boolean
  running: boolean
  mode: string
  ato: string
}): string {
  if (!serviceStarted) return "Step 1 — Press Start Service. The train will drive itself in ATO (automatic) mode."
  if (mode === "EMERGENCY") return "Emergency brake is active. Wait for the train to stop, then press Reset Brake."
  if (mode === "ATO" && ato === "ACTIVE")
    return "Train is driving automatically. To practise manual driving, press Simulate ATO Failure, then ATO Cutout."
  if (mode === "ATO" && ato === "FAILED")
    return "ATO has failed. Press ATO Cutout to switch to manual (RM) driving without stopping the train."
  if (mode === "RM")
    return "You are now driving manually. Use Power / Coast / Brake below. ATP still protects you from overspeeding."
  if (!running) return "Service paused. Press Resume to continue."
  return ""
}

export function ControlPanel() {
  const {
    running,
    serviceStarted,
    mode,
    ato,
    atp,
    speed,
    throttle,
    startService,
    pause,
    reset,
    atoFailure,
    atoCutout,
    restoreAto,
    setThrottle,
    forceEmergency,
    emergencyReset,
  } = useTrainControl()

  const inRM = mode === "RM"
  const inEmergency = mode === "EMERGENCY"
  const canRestoreAto = inRM && ato !== "FAILED" && ato !== "CUTOUT" && atp !== "INTERVENING"
  const canResetEmergency = inEmergency && speed <= 0.5

  const hint = nextStepHint({ serviceStarted, running, mode, ato })

  return (
    <div className="flex flex-col gap-4">
      {/* guided next-step banner */}
      {hint && (
        <div className="rounded-md border border-signal-info/40 bg-signal-info/10 px-3 py-2">
          <p className="font-mono text-[9px] uppercase tracking-widest text-signal-info">What to do next</p>
          <p className="mt-0.5 text-[11px] leading-snug text-foreground">{hint}</p>
        </div>
      )}

      {/* service */}
      <Section title="Service" hint="Start, pause, or reset the whole simulation.">
        <div className="grid grid-cols-2 gap-2">
          {!running ? (
            <Button onClick={startService} className="font-mono text-xs">
              {serviceStarted ? "Resume" : "Start Service"}
            </Button>
          ) : (
            <Button onClick={pause} variant="secondary" className="font-mono text-xs">
              Pause
            </Button>
          )}
          <Button onClick={reset} variant="outline" className="font-mono text-xs">
            Reset
          </Button>
        </div>
      </Section>

      {/* ATO control */}
      <Section
        title="Automatic Driving (ATO)"
        hint="ATO drives the train by itself. These buttons let you fail it and hand control to the driver — or give control back."
      >
        <ActionButton
          label="Simulate ATO Failure"
          desc="Pretend the auto-driver breaks down. The train keeps moving."
          onClick={atoFailure}
          variant="outline"
          disabled={ato === "FAILED" || ato === "CUTOUT"}
        />
        <ActionButton
          label="ATO Cutout → Manual"
          desc="Switch off the auto-driver and take manual control — no stop needed."
          onClick={atoCutout}
          disabled={ato === "CUTOUT" || inEmergency}
          className="border border-signal-warn/50 bg-signal-warn/15 text-signal-warn hover:bg-signal-warn/25"
        />
        <ActionButton
          label="Restore ATO"
          desc="Give control back to the auto-driver (only when ATO is healthy)."
          onClick={restoreAto}
          variant="outline"
          disabled={!canRestoreAto}
        />
      </Section>

      {/* RM driver controls */}
      <Section
        title="Manual Driving (RM)"
        hint="The driver's throttle. Power speeds up, Coast freewheels, Brake slows down. ATP still caps your speed."
      >
        <div className="grid grid-cols-3 gap-2">
          <Button
            onClick={() => setThrottle("POWER")}
            disabled={!inRM}
            variant={inRM && throttle === "POWER" ? "default" : "outline"}
            className="font-mono text-xs"
          >
            Power
          </Button>
          <Button
            onClick={() => setThrottle("COAST")}
            disabled={!inRM}
            variant={inRM && throttle === "COAST" ? "default" : "outline"}
            className="font-mono text-xs"
          >
            Coast
          </Button>
          <Button
            onClick={() => setThrottle("BRAKE")}
            disabled={!inRM}
            variant={inRM && throttle === "BRAKE" ? "default" : "outline"}
            className="font-mono text-xs"
          >
            Brake
          </Button>
        </div>
        {!inRM && (
          <p className="text-[11px] leading-snug text-muted-foreground">
            Locked. These work only when driving manually — use “ATO Cutout → Manual” above first.
          </p>
        )}
      </Section>

      {/* emergency */}
      <Section
        title="Emergency Brake"
        hint="Hardest possible stop. ATP also triggers this automatically if the train overspeeds."
      >
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={forceEmergency}
            disabled={inEmergency}
            className="border border-signal-alarm/60 bg-signal-alarm/15 font-mono text-xs text-signal-alarm hover:bg-signal-alarm/25"
          >
            Emergency Brake
          </Button>
          <Button
            onClick={emergencyReset}
            disabled={!canResetEmergency}
            variant="outline"
            className="font-mono text-xs"
          >
            Reset Brake
          </Button>
        </div>
      </Section>
    </div>
  )
}
