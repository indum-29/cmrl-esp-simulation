"use client"

import { useTrainControl, type Mode } from "@/lib/train-control-store"
import { cn } from "@/lib/utils"

type Tone = "safe" | "warn" | "alarm" | "info" | "idle"

const toneStyles: Record<Tone, { dot: string; text: string; ring: string }> = {
  safe: { dot: "bg-signal-safe", text: "text-signal-safe", ring: "border-signal-safe/40" },
  warn: { dot: "bg-signal-warn", text: "text-signal-warn", ring: "border-signal-warn/40" },
  alarm: { dot: "bg-signal-alarm", text: "text-signal-alarm", ring: "border-signal-alarm/50" },
  info: { dot: "bg-signal-info", text: "text-signal-info", ring: "border-signal-info/40" },
  idle: { dot: "bg-muted-foreground", text: "text-muted-foreground", ring: "border-border" },
}

function Indicator({
  label,
  value,
  tone,
  pulse,
}: {
  label: string
  value: string
  tone: Tone
  pulse?: boolean
}) {
  const s = toneStyles[tone]
  return (
    <div className={cn("flex items-center justify-between rounded-md border bg-secondary/30 px-3 py-2", s.ring)}>
      <div className="flex items-center gap-2">
        <span className={cn("relative inline-flex size-2.5 rounded-full", s.dot)}>
          {pulse && <span className={cn("absolute inset-0 animate-ping rounded-full opacity-75", s.dot)} />}
        </span>
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span>
      </div>
      <span className={cn("font-mono text-xs font-semibold uppercase tracking-wide", s.text)}>{value}</span>
    </div>
  )
}

function modeTone(mode: Mode): Tone {
  if (mode === "ATO") return "safe"
  if (mode === "RM") return "warn"
  return "alarm"
}

export function StatusPanel() {
  const { mode, ato, atp, doors, throttle } = useTrainControl()

  const atoTone: Tone =
    ato === "ACTIVE" ? "safe" : ato === "FAILED" ? "alarm" : ato === "CUTOUT" ? "warn" : "idle"
  const atpTone: Tone = atp === "SUPERVISING" ? "safe" : atp === "OVERSPEED" ? "warn" : "alarm"
  const cutout = ato === "CUTOUT"

  return (
    <div className="flex flex-col gap-2">
      {/* big mode banner */}
      <div
        className={cn(
          "rounded-md border px-3 py-3 text-center",
          mode === "ATO" && "border-signal-safe/50 bg-signal-safe/10",
          mode === "RM" && "border-signal-warn/50 bg-signal-warn/10",
          mode === "EMERGENCY" && "border-signal-alarm/60 bg-signal-alarm/15",
        )}
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Operating Mode</p>
        <p className={cn("font-mono text-2xl font-bold tracking-tight", toneStyles[modeTone(mode)].text)}>
          {mode === "ATO" ? "ATO" : mode === "RM" ? "RM" : "EMERGENCY"}
        </p>
        <p className="font-mono text-[10px] tracking-wide text-muted-foreground">
          {mode === "ATO"
            ? "Automatic Train Operation"
            : mode === "RM"
              ? "Restricted Manual"
              : "Emergency Brake Active"}
        </p>
        <p className="mt-1 text-[10px] leading-snug text-muted-foreground">
          {mode === "ATO"
            ? "The train drives itself."
            : mode === "RM"
              ? "The driver controls the train by hand."
              : "Train is making a full safety stop."}
        </p>
      </div>

      <p className="px-1 text-[10px] leading-snug text-muted-foreground">
        ATP is the safety system that always watches your speed and brakes for you if you go too fast.
      </p>

      <Indicator label="ATP Protection" value={atp} tone={atpTone} pulse={atp !== "SUPERVISING"} />
      <Indicator
        label="ATO System"
        value={ato}
        tone={atoTone}
        pulse={ato === "FAILED"}
      />
      <Indicator
        label="ATO Cutout"
        value={cutout ? "ENGAGED" : "NORMAL"}
        tone={cutout ? "warn" : "idle"}
      />
      <Indicator
        label="Doors"
        value={doors}
        tone={doors === "CLOSED" ? "safe" : doors === "OPEN" ? "info" : "warn"}
      />
      {mode === "RM" && (
        <Indicator
          label="RM Demand"
          value={throttle}
          tone={throttle === "POWER" ? "info" : throttle === "BRAKE" ? "warn" : "idle"}
        />
      )}
    </div>
  )
}
