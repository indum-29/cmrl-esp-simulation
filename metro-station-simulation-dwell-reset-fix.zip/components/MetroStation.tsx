import { useRef } from 'react'
import * as THREE from 'three'

export default function MetroStation() {
  const stationRef = useRef<THREE.Group>(null)

  return (
    <group ref={stationRef}>
      {/* Main tunnel structure */}
      <mesh position={[0, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[50, 12, 60]} />
        <meshStandardMaterial color="#d4d4d8" metalness={0.3} roughness={0.7} side={THREE.BackSide} />
      </mesh>

      {/* Platform 1 - Left Side */}
      <mesh position={[-8, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[10, 1, 40]} />
        <meshStandardMaterial color="#f4f4f5" />
      </mesh>

      {/* Platform 2 - Right Side */}
      <mesh position={[8, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[10, 1, 40]} />
        <meshStandardMaterial color="#f4f4f5" />
      </mesh>

      {/* Track 1 - Left */}
      <group position={[-2.5, -0.5, 0]}>
        {/* Rail */}
        <mesh castShadow receiveShadow>
          <boxGeometry args={[0.5, 0.3, 40]} />
          <meshStandardMaterial color="#71717a" metalness={0.8} roughness={0.2} />
        </mesh>
        {/* Sleepers/Ties */}
        {Array.from({ length: 20 }).map((_, i) => (
          <mesh key={`sleeper-left-${i}`} position={[0, -0.4, -20 + i * 4]} castShadow>
            <boxGeometry args={[5, 0.2, 0.4]} />
            <meshStandardMaterial color="#3f3f46" />
          </mesh>
        ))}
      </group>

      {/* Track 2 - Right */}
      <group position={[2.5, -0.5, 0]}>
        {/* Rail */}
        <mesh castShadow receiveShadow>
          <boxGeometry args={[0.5, 0.3, 40]} />
          <meshStandardMaterial color="#71717a" metalness={0.8} roughness={0.2} />
        </mesh>
        {/* Sleepers/Ties */}
        {Array.from({ length: 20 }).map((_, i) => (
          <mesh key={`sleeper-right-${i}`} position={[0, -0.4, -20 + i * 4]} castShadow>
            <boxGeometry args={[5, 0.2, 0.4]} />
            <meshStandardMaterial color="#3f3f46" />
          </mesh>
        ))}
      </group>

      {/* Support Columns */}
      {Array.from({ length: 8 }).map((_, i) => (
        <group key={`column-${i}`} position={[-20 + i * 6, 0, -25]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[0.8, 12, 0.8]} />
            <meshStandardMaterial color="#404040" />
          </mesh>
        </group>
      ))}

      {/* Yellow Safety Line on Platform 1 */}
      <mesh position={[-8, 1.05, 0]}>
        <boxGeometry args={[0.3, 0.02, 40]} />
        <meshStandardMaterial color="#fbbf24" />
      </mesh>

      {/* Yellow Safety Line on Platform 2 */}
      <mesh position={[8, 1.05, 0]}>
        <boxGeometry args={[0.3, 0.02, 40]} />
        <meshStandardMaterial color="#fbbf24" />
      </mesh>

      {/* Fence Platform 1 - Left */}
      {Array.from({ length: 10 }).map((_, i) => (
        <group key={`fence-left-${i}`} position={[-13, 1.5, -18 + i * 4]}>
          <mesh castShadow>
            <boxGeometry args={[0.2, 1.5, 0.2]} />
            <meshStandardMaterial color="#1e40af" />
          </mesh>
          {i < 9 && (
            <mesh position={[0, 0.5, 2]}>
              <boxGeometry args={[0.8, 0.1, 4]} />
              <meshStandardMaterial color="#1e40af" />
            </mesh>
          )}
        </group>
      ))}

      {/* Fence Platform 2 - Right */}
      {Array.from({ length: 10 }).map((_, i) => (
        <group key={`fence-right-${i}`} position={[13, 1.5, -18 + i * 4]}>
          <mesh castShadow>
            <boxGeometry args={[0.2, 1.5, 0.2]} />
            <meshStandardMaterial color="#1e40af" />
          </mesh>
          {i < 9 && (
            <mesh position={[0, 0.5, 2]}>
              <boxGeometry args={[0.8, 0.1, 4]} />
              <meshStandardMaterial color="#1e40af" />
            </mesh>
          )}
        </group>
      ))}

      {/* Static People on Platform 1 */}
      {Array.from({ length: 5 }).map((_, i) => (
        <group key={`person-platform1-${i}`} position={[-6 + i * 2, 1.5, -8 + (i % 2) * 4]}>
          <mesh castShadow>
            <capsuleGeometry args={[0.3, 1.2, 4, 8]} />
            <meshStandardMaterial color={['#3b82f6', '#ef4444', '#8b5cf6'][i % 3]} />
          </mesh>
        </group>
      ))}

      {/* Static People on Platform 2 */}
      {Array.from({ length: 5 }).map((_, i) => (
        <group key={`person-platform2-${i}`} position={[6 + i * 2, 1.5, 8 + (i % 2) * 4]}>
          <mesh castShadow>
            <capsuleGeometry args={[0.3, 1.2, 4, 8]} />
            <meshStandardMaterial color={['#06b6d4', '#f59e0b', '#ec4899'][i % 3]} />
          </mesh>
        </group>
      ))}

      {/* Service Help Area - Platform 1 Left */}
      <group position={[-15, 1.5, -20]}>
        {/* Help button box */}
        <mesh castShadow>
          <boxGeometry args={[2, 1.5, 0.2]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.3} />
        </mesh>
        {/* Text indicator */}
        <mesh position={[0, 0, 0.2]}>
          <boxGeometry args={[1.8, 0.3, 0.1]} />
          <meshStandardMaterial color="#f59e0b" />
        </mesh>
      </group>

      {/* Service Help Area - Platform 2 Right */}
      <group position={[15, 1.5, 20]}>
        {/* Help button box */}
        <mesh castShadow>
          <boxGeometry args={[2, 1.5, 0.2]} />
          <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={0.3} />
        </mesh>
        {/* Text indicator */}
        <mesh position={[0, 0, 0.2]}>
          <boxGeometry args={[1.8, 0.3, 0.1]} />
          <meshStandardMaterial color="#f59e0b" />
        </mesh>
      </group>

      {/* Enhanced track visibility - add subtle glow to track area */}
      <mesh position={[0, -0.3, 0]}>
        <boxGeometry args={[6, 0.5, 40]} />
        <meshStandardMaterial 
          color="#404040" 
          emissive="#1a1a1a" 
          emissiveIntensity={0.1}
          transparent={true}
          opacity={0.3}
        />
      </mesh>
    </group>
  )
}
