interface TrainingPanelProps {
  activeScenario: string | null
  onScenarioClick: (scenario: string) => void
  onReset: () => void
}

export default function TrainingPanel({
  activeScenario,
  onScenarioClick,
  onReset,
}: TrainingPanelProps) {
  const scenarios = [
    { id: 'person-falls-1', label: 'PERSON FALLS\\PLATFORM 1' },
    { id: 'object-falls-1', label: 'OBJECT FALLS\\PLATFORM 1' },
    { id: 'person-falls-2', label: 'PERSON FALLS\\PLATFORM 2' },
    { id: 'object-falls-2', label: 'OBJECT FALLS\\PLATFORM 2' },
  ]

  return (
    <div className="absolute left-0 top-0 z-10 h-full w-96 bg-gray-900 bg-opacity-85 text-white p-4 overflow-y-auto flex flex-col">
      {/* Header */}
      <div className="mb-6 border-b border-gray-700 pb-4">
        <div className="text-xs font-mono text-gray-400 tracking-wider mb-1">
          METRO ESP TRAINING SIMULATOR
        </div>
        <h1 className="text-2xl font-bold">Elevated Station — Shared Risk Zone</h1>
      </div>

      {/* Training Scenarios Section */}
      <div className="mb-6">
        <h2 className="text-xs font-mono text-gray-400 tracking-wider mb-3 uppercase">
          Training Scenarios
        </h2>

        <div className="space-y-2 mb-4">
          {scenarios.map((scenario) => (
            <button
              key={scenario.id}
              onClick={() => onScenarioClick(scenario.id)}
              className={`w-full px-3 py-2 text-sm font-mono text-left transition-all ${
                activeScenario === scenario.id
                  ? 'bg-blue-600 border-l-4 border-blue-400'
                  : 'bg-gray-800 hover:bg-gray-700 border-l-4 border-gray-700'
              }`}
            >
              {scenario.label}
            </button>
          ))}
        </div>
      </div>

      {/* Scenario Status */}
      <div className="mb-6 bg-gray-800 p-3 rounded border border-gray-700">
        <h3 className="text-xs font-mono text-gray-400 tracking-wider mb-2 uppercase">
          Scenario Active
        </h3>
        {activeScenario ? (
          <div className="space-y-2">
            <p className="text-xs text-gray-300">
              Select a scenario, then press START to trigger the incident on the selected platform.
            </p>
            <div className="bg-blue-900 border border-blue-500 p-2 rounded mt-2">
              <p className="text-sm font-mono text-blue-200">
                {scenarios.find((s) => s.id === activeScenario)?.label}
              </p>
            </div>
            <button
              onClick={onReset}
              className="w-full mt-3 px-3 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-mono rounded transition-all"
            >
              RESET SCENARIO
            </button>
          </div>
        ) : (
          <p className="text-xs text-gray-400">No active scenario</p>
        )}
      </div>

      {/* Info Box */}
      <div className="bg-gray-800 border border-gray-700 p-3 rounded">
        <h3 className="text-xs font-mono text-gray-400 tracking-wider mb-2 uppercase">
          Instructions
        </h3>
        <ol className="text-xs text-gray-300 space-y-1 list-decimal list-inside">
          <li>Select a training scenario from the list above</li>
          <li>When you press a scenario button, an incident will be triggered</li>
          <li>Watch as a person falls into the track in the 3D scene</li>
          <li>The ESP alert system will detect the intrusion</li>
          <li>Use the RESET button to clear the scenario</li>
        </ol>
      </div>

      {/* Footer Info */}
      <div className="mt-auto pt-4 border-t border-gray-700">
        <div className="text-xs text-gray-500 font-mono">
          <div>Version: 1.0.0</div>
          <div>Training Mode: Active</div>
        </div>
      </div>
    </div>
  )
}
