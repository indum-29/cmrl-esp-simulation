"use client"

import { Suspense } from "react"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera, Environment } from "@react-three/drei"
import { EspProvider, useEsp } from "@/lib/esp-store"
import { ScenarioProvider } from "@/lib/scenario-context"
import { FallingPersonProvider } from "@/lib/falling-person-context"
import { PlatformESPProvider } from "@/lib/platform-esp-context"
import { DoorSyncProvider } from "@/lib/door-sync-context"
import { ElevatedStation } from "./elevated-station"
import { UndergroundStation } from "./underground-station"
import { ControlPanel } from "./control-panel"

function Scene() {
  const { mode } = useEsp()
  return (
    <>
      {mode === "elevated" ? (
        <fog attach="fog" args={["#cdd9e6", 70, 150]} />
      ) : (
        <>
          <color attach="background" args={["#101216"]} />
          <fog attach="fog" args={["#101216", 55, 130]} />
        </>
      )}
      {/* station viewpoint: high, long aerial view down the platforms */}
      <PerspectiveCamera
        makeDefault
        fov={55}
        position={mode === "elevated" ? [18, 5.5, 22] : [4, 4.5, 30]}
      />
      <OrbitControls
        target={mode === "elevated" ? [0, 1.4, 0] : [0, 1.4, -4]}
        enablePan
        minDistance={8}
        maxDistance={120}
        maxPolarAngle={Math.PI / 2.05}
        minPolarAngle={mode === "elevated" ? 0.12 : 0.2}
      />
      <Suspense fallback={null}>
        {mode === "elevated" ? <ElevatedStation /> : <UndergroundStation />}
        <Environment preset={mode === "elevated" ? "city" : "warehouse"} frames={1} />
      </Suspense>
    </>
  )
}

/** The 3D view + ESP control panel, without its own provider. Must be rendered inside an EspProvider. */
export function SimulatorScene() {
  return (
    <div className="relative h-screen w-full overflow-hidden bg-background">
      <Canvas
        shadows={false}
        dpr={[1, 1.35]}
        gl={{ antialias: true, powerPreference: "high-performance" }}
      >
        <Scene />
      </Canvas>
      <ControlPanel />
    </div>
  )
}

export function Simulator() {
  return (
    <ScenarioProvider>
      <FallingPersonProvider>
        <PlatformESPProvider>
          <EspProvider>
            <DoorSyncProvider>
              <SimulatorScene />
            </DoorSyncProvider>
          </EspProvider>
        </PlatformESPProvider>
      </FallingPersonProvider>
    </ScenarioProvider>
  )
}
