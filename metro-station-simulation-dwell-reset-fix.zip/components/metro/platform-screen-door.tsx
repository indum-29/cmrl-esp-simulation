"use client"

import { useMemo, useRef, type MutableRefObject } from "react"
import { useFrame } from "@react-three/fiber"
import type { Group } from "three"

interface PlatformScreenDoorProps {
  x: number
  z?: number
  length: number
  psdOpenRef: MutableRefObject<number>
  accent?: string
  /** Show an object (umbrella) caught in one of the PSD door units, like a
   *  real-world platform incident. It hangs on the door frame at all times —
   *  open or closed — exactly like the reference photo, and only comes loose
   *  when `stuckObjectFallen` is set. */
  stuckObject?: boolean
  /** Which door unit (0-indexed) the stuck object appears at. Defaults to
   *  the unit nearest the platform center. */
  stuckUnitIndex?: number
  /** When true, the stuck object drops off the door and settles on the
   *  platform floor — e.g. once the platform ESP emergency-stop plunger is
   *  pressed. Setting it back to false swings the object back up onto the
   *  hook, ready to be caught again. */
  stuckObjectFallen?: boolean
}

/* ---- shared proportions -------------------------------------------------- */
const DOOR_HEIGHT = 2.3
const DOOR_Y = 1.15 + DOOR_HEIGHT / 2
const MAX_SLIDE = 0.62 // max distance each leaf slides away from center
const UNIT_SPACING = 6.0 // distance between door-unit centers (~ one car length)
const UNIT_HALF_WIDTH = 0.85 // half-width of the opening each door unit covers

// Dark tinted glass matching real-world PSD units (see reference photo):
// near-black, slightly reflective, with a visible but not fully opaque tint.
const GLASS_COLOR = "#14171c"
const GLASS_OPACITY = 0.6
const FRAME_COLOR = "#0b0d10"
const LAMP_COLOR = "#ff9a2e" // amber door lamp, like the reference photo

/** One sliding door leaf pair (the part that actually opens), styled like a real PSD unit. */
function DoorUnit({ z, psdOpenRef, accent }: { z: number; psdOpenRef: MutableRefObject<number>; accent: string }) {
  const leftPanelRef = useRef<Group>(null)
  const rightPanelRef = useRef<Group>(null)
  const currentSlideRef = useRef(0)

  useFrame(() => {
    if (!leftPanelRef.current || !rightPanelRef.current) return
    const target = psdOpenRef.current * MAX_SLIDE
    currentSlideRef.current += (target - currentSlideRef.current) * 0.12
    leftPanelRef.current.position.z = z - currentSlideRef.current
    rightPanelRef.current.position.z = z + currentSlideRef.current
  })

  const leafWidth = UNIT_HALF_WIDTH * 0.92

  const Leaf = ({ groupRef }: { groupRef: MutableRefObject<Group | null> }) => (
    <group ref={groupRef} position={[0, 0, z]}>
      {/* dark tinted glass body */}
      <mesh position={[0, DOOR_Y, 0]}>
        <boxGeometry args={[0.3, DOOR_HEIGHT, leafWidth]} />
        <meshStandardMaterial
          color={GLASS_COLOR}
          roughness={0.1}
          metalness={0.12}
          transparent
          opacity={GLASS_OPACITY}
          envMapIntensity={0.4}
        />
      </mesh>
      {/* black aluminum edge frame */}
      <mesh position={[0, DOOR_Y, leafWidth / 2 - 0.02]}>
        <boxGeometry args={[0.34, DOOR_HEIGHT, 0.05]} />
        <meshStandardMaterial color={FRAME_COLOR} roughness={0.3} metalness={0.7} />
      </mesh>
      <mesh position={[0, DOOR_Y, -leafWidth / 2 + 0.02]}>
        <boxGeometry args={[0.34, DOOR_HEIGHT, 0.05]} />
        <meshStandardMaterial color={FRAME_COLOR} roughness={0.3} metalness={0.7} />
      </mesh>
      {/* subtle horizontal reflection line, like real glass panels */}
      <mesh position={[0.16, DOOR_Y + 0.3, 0]}>
        <boxGeometry args={[0.02, 0.05, leafWidth - 0.1]} />
        <meshStandardMaterial color="#ffffff" transparent opacity={0.12} />
      </mesh>
      {/* small amber status lamp at the top corner — brightens green when open */}
      <mesh position={[0.17, DOOR_Y + DOOR_HEIGHT / 2 - 0.15, leafWidth / 2 - 0.15]}>
        <circleGeometry args={[0.05, 12]} />
        <meshStandardMaterial
          color={psdOpenRef.current > 0.5 ? "#2ee66b" : LAMP_COLOR}
          emissive={psdOpenRef.current > 0.5 ? "#2ee66b" : LAMP_COLOR}
          emissiveIntensity={0.9}
        />
      </mesh>
    </group>
  )

  return (
    <>
      <Leaf groupRef={leftPanelRef} />
      <Leaf groupRef={rightPanelRef} />
    </>
  )
}

/**
 * A closed umbrella caught in the PSD track — a common, non-graphic
 * real-world platform incident (see reference photo). It hangs just off the
 * glass face on the platform side, fully decoupled from the sliding leaf
 * meshes, so it never intersects or z-fights with the animated doors.
 *
 * Unlike the doors themselves, it stays hooked in place at all times —
 * whether the PSD is open or shut, exactly like the reference photo — and
 * only drops when `fallen` is set (e.g. the platform ESP plunger is pressed).
 * Setting `fallen` back to false swings it back up onto the hook so the demo
 * can be replayed.
 */
function StuckObject({ z, side, fallen = false }: { z: number; side: 1 | -1; fallen?: boolean }) {
  const groupRef = useRef<Group>(null)
  const dropRef = useRef(0) // how far it has fallen from the hooked position (0 = still hooked)
  const velRef = useRef(0) // fall speed, builds up under gravity
  const swingRef = useRef(0) // tumble rotation as it drops / swings back up
  const settledRef = useRef(false)

  const HANG_X = side * 0.34 // just off the glass face, toward the platform side
  const TOP_Y = DOOR_Y + DOOR_HEIGHT / 2 - 0.4
  const FLOOR_Y = DOOR_Y - DOOR_HEIGHT / 2 // platform slab top, matching the rest of the scene
  const CANOPY_BOTTOM = TOP_Y - 0.935 // lowest point of the closed canopy tip
  const FALL_DROP = CANOPY_BOTTOM - (FLOOR_Y + 0.03) // distance to travel before it rests on the platform

  useFrame((_, dtRaw) => {
    if (!groupRef.current) return
    const dt = Math.min(dtRaw, 0.05)

    if (fallen) {
      if (!settledRef.current) {
        // simple gravity fall + tumble, then come to rest on the platform floor
        velRef.current += 9.8 * dt
        dropRef.current += velRef.current * dt
        swingRef.current += dt * 5
        if (dropRef.current >= FALL_DROP) {
          dropRef.current = FALL_DROP
          swingRef.current = Math.PI / 2.05 // lands lying on its side
          settledRef.current = true
        }
      }
    } else {
      // ESP reset — swing it back up onto the hook, ready to snag again
      dropRef.current += (0 - dropRef.current) * Math.min(1, dt * 6)
      swingRef.current += (0 - swingRef.current) * Math.min(1, dt * 6)
      velRef.current = 0
      settledRef.current = false
      if (Math.abs(dropRef.current) < 0.002) dropRef.current = 0
      if (Math.abs(swingRef.current) < 0.002) swingRef.current = 0
    }

    groupRef.current.position.y = -dropRef.current
    groupRef.current.position.x = HANG_X + side * dropRef.current * 0.18 // swings clear of the door as it falls
    groupRef.current.rotation.z = -side * Math.min(swingRef.current, Math.PI / 2.05)
  })

  return (
    <group ref={groupRef} position={[HANG_X, 0, z]}>
      {/* curved handle hooked over the door frame/seam */}
      <mesh position={[0, TOP_Y, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <torusGeometry args={[0.09, 0.017, 8, 16, Math.PI * 1.3]} />
        <meshStandardMaterial color="#1c1c1e" roughness={0.5} metalness={0.3} />
      </mesh>
      {/* shaft trailing down from the hook */}
      <mesh position={[0, TOP_Y - 0.42, 0]} castShadow>
        <cylinderGeometry args={[0.013, 0.013, 0.75, 8]} />
        <meshStandardMaterial color="#2a2a2c" roughness={0.5} metalness={0.3} />
      </mesh>
      {/* bunched, closed canopy — tip hanging down */}
      <mesh position={[0, TOP_Y - 0.66, 0]} rotation={[Math.PI, 0, 0]} castShadow>
        <coneGeometry args={[0.16, 0.55, 10]} />
        <meshStandardMaterial color="#161616" roughness={0.75} />
      </mesh>
      {/* strap band holding the canopy closed */}
      <mesh position={[0, TOP_Y - 0.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.1, 0.012, 8, 16]} />
        <meshStandardMaterial color="#3a3a3c" roughness={0.6} />
      </mesh>
    </group>
  )
}

/** A fixed (non-sliding) dark glass wall segment between door units. */
function FixedPanel({ z, width }: { z: number; width: number }) {
  if (width <= 0.05) return null
  return (
    <group position={[0, 0, z]}>
      <mesh position={[0, DOOR_Y, 0]}>
        <boxGeometry args={[0.3, DOOR_HEIGHT, width]} />
        <meshStandardMaterial
          color={GLASS_COLOR}
          roughness={0.1}
          metalness={0.12}
          transparent
          opacity={GLASS_OPACITY}
          envMapIntensity={0.4}
        />
      </mesh>
      {/* mullion at panel center for structural read */}
      <mesh position={[0, DOOR_Y, 0]}>
        <boxGeometry args={[0.34, DOOR_HEIGHT, 0.06]} />
        <meshStandardMaterial color={FRAME_COLOR} roughness={0.3} metalness={0.7} />
      </mesh>
    </group>
  )
}

/**
 * Automatic platform screen doors composed of repeating dark-glass door units
 * (each with sliding left/right leaves) separated by fixed glass wall panels —
 * matching real-world PSD systems where only discrete door modules open,
 * aligned roughly to where the train's own doors will be.
 */
export function PlatformScreenDoor({
  x,
  z = 0,
  length,
  psdOpenRef,
  accent = "#e6197d",
  stuckObject = false,
  stuckUnitIndex,
  stuckObjectFallen = false,
}: PlatformScreenDoorProps) {
  // Lay out door-unit centers evenly across the platform length.
  const unitZs = useMemo(() => {
    const zs: number[] = []
    const half = length / 2
    const start = -half + UNIT_SPACING / 2
    for (let pos = start; pos <= half - UNIT_SPACING / 2 + 0.01; pos += UNIT_SPACING) {
      zs.push(pos)
    }
    return zs
  }, [length])

  // Fixed glass panels fill every gap: before the first unit, between units, and after the last.
  const fixedSegments = useMemo(() => {
    const half = length / 2
    const segs: { z: number; width: number }[] = []
    const edges = [-half, ...unitZs, half]
    for (let i = 0; i < edges.length - 1; i++) {
      const gapStart = i === 0 ? edges[i] : edges[i] + UNIT_HALF_WIDTH
      const gapEnd = i === edges.length - 2 ? edges[i + 1] : edges[i + 1] - UNIT_HALF_WIDTH
      const width = gapEnd - gapStart
      if (width > 0.05) segs.push({ z: (gapStart + gapEnd) / 2, width })
    }
    return segs
  }, [unitZs, length])

  return (
    <group position={[x, 0, z]}>
      {/* fixed glass wall segments between door units */}
      {fixedSegments.map((seg, idx) => (
        <FixedPanel key={idx} z={seg.z} width={seg.width} />
      ))}

      {/* sliding door units */}
      {unitZs.map((unitZ, idx) => (
        <DoorUnit key={idx} z={unitZ} psdOpenRef={psdOpenRef} accent={accent} />
      ))}

      {/* object caught in the door track, at one door unit — stays hooked in
          place at all times (open or closed door), never intersects the
          sliding leaves since it's rendered independently of them, and only
          drops once stuckObjectFallen is set (e.g. ESP plunger pressed). */}
      {stuckObject && unitZs.length > 0 && (
        <StuckObject
          z={unitZs[stuckUnitIndex ?? Math.floor(unitZs.length / 2)] ?? 0}
          side={x < 0 ? 1 : -1}
          fallen={stuckObjectFallen}
        />
      )}

      {/* Top frame header - black structural beam running the full platform length,
          matching the dark roofline of the reference photo (no colored banding) */}
      <mesh position={[0, DOOR_Y + DOOR_HEIGHT / 2 + 0.32, 0]} castShadow>
        <boxGeometry args={[0.75, 0.54, length]} />
        <meshStandardMaterial color="#111214" roughness={0.45} metalness={0.4} />
      </mesh>

      {/* Slim silver trim line under the header, like the metallic strip in the reference photo */}
      <mesh position={[0, DOOR_Y + DOOR_HEIGHT / 2 + 0.08, 0]}>
        <boxGeometry args={[0.76, 0.05, length]} />
        <meshStandardMaterial color="#c7cbd0" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Black frame/mullion detail at top */}
      <mesh position={[0, DOOR_Y + DOOR_HEIGHT / 2 + 0.38, 0]}>
        <boxGeometry args={[0.76, 0.12, length]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.4} metalness={0.5} />
      </mesh>
    </group>
  )
}
