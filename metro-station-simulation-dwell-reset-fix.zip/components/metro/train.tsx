"use client"

import { useRef, useEffect, type MutableRefObject } from "react"
import { useFrame } from "@react-three/fiber"
import { Text } from "@react-three/drei"
import type { Group, Mesh } from "three"
import { EB_DECEL_MS2 } from "@/lib/esp-store"
import { useDoorSync } from "@/lib/door-sync-context"

/** Scene units travelled per second per km/h of real speed.
 *  Chosen so 50 km/h ≈ 6.5 u/s, matching the prior visual cruise. */
const KMH_TO_SCENE = 0.13
/** Constant scene deceleration during an emergency brake.
 *  Derived from the real 1.3 m/s² rate so stop TIME scales with speed
 *  exactly as the physics dictates (faster train → longer stop). */
const EB_DECEL_SCENE = KMH_TO_SCENE * EB_DECEL_MS2 * 3.6

interface TrainProps {
  x: number
  stopped: boolean
  color?: string
  accentColor?: string
  cars?: number
  /** Real cruise speed in km/h — enables physics-based emergency braking. */
  speedKmh?: number
  /** Legacy fixed scene speed (used when speedKmh is not provided). */
  cruise?: number
  direction?: 1 | -1
  loopLimit?: number
  startZ?: number
  label?: string
  /** When true the train runs an automatic arrive → open doors → dwell → depart cycle at the platform. */
  dock?: boolean
  /** Longitudinal position (scene z) where the train stops at the platform. */
  dockZ?: number
  /** Local side (-1 / +1) that faces the platform — used for door opening + the stuck object. */
  platformSide?: 1 | -1
  /** Show a passenger object caught in the platform-side door of the lead car. */
  stuckObject?: boolean
  /** Track ID (A or B) for door synchronization. */
  track?: "A" | "B"
  /** How long (seconds) the train dwells at the platform with doors open
   *  before departing. Defaults to 6s (used by the underground station);
   *  the elevated station passes a short 1s dwell instead. */
  dwellSeconds?: number
  /** Bump this (e.g. an incrementing counter) to force the train to restart
   *  its arrive → dwell → depart cycle cleanly — used after an ESP reset so
   *  a train that was frozen mid-cycle reliably resumes moving instead of
   *  possibly idling out a stale dwell timer. */
  resetSignal?: number
}

/** A pair of sliding door leaves on one side of a car. Reads a shared open ref (0 closed → 1 open). */
function SlidingDoor({
  side,
  doorOpenRef,
  accentColor,
}: {
  side: 1 | -1
  doorOpenRef: MutableRefObject<number>
  accentColor: string
}) {
  const leafFront = useRef<Group>(null)
  const leafBack = useRef<Group>(null)
  const lampTop = useRef<Mesh>(null)
  const lampBottom = useRef<Mesh>(null)
  const closedGap = 0.4 // half door-leaf width when shut
  const travel = 0.78 // how far each leaf slides open
  const LAMP_COLOR = "#ff9a2e" // amber door lamps either side of the opening, as in the reference photo

  useFrame(() => {
    const o = doorOpenRef.current
    if (leafBack.current) leafBack.current.position.z = -closedGap - o * travel
    if (leafFront.current) leafFront.current.position.z = closedGap + o * travel
    // amber lamps glow brighter whenever the doors are open or moving
    const lampIntensity = o > 0.02 ? 1.5 : 0.3
    if (lampTop.current) (lampTop.current.material as any).emissiveIntensity = lampIntensity
    if (lampBottom.current) (lampBottom.current.material as any).emissiveIntensity = lampIntensity
  })

  return (
    <group position={[side * 1.43, 1.35, 0]}>
      {/* dark door pocket / threshold so the opening reads clearly */}
      <mesh position={[-0.01, 0, 0]}>
        <boxGeometry args={[0.02, 1.9, 1.7]} />
        <meshStandardMaterial color="#0d1218" roughness={0.9} />
      </mesh>

      {/* amber door-status lamps flanking the doorway, top and bottom of the threshold */}
      <mesh ref={lampTop} position={[0.05, 0.86, 0]}>
        <boxGeometry args={[0.04, 0.14, 0.14]} />
        <meshStandardMaterial color={LAMP_COLOR} emissive={LAMP_COLOR} emissiveIntensity={0.3} />
      </mesh>
      <mesh ref={lampBottom} position={[0.05, -0.86, 0]}>
        <boxGeometry args={[0.04, 0.14, 0.14]} />
        <meshStandardMaterial color={LAMP_COLOR} emissive={LAMP_COLOR} emissiveIntensity={0.3} />
      </mesh>

      {[leafBack, leafFront].map((r, i) => (
        <group key={i} ref={r} position={[0, 0, i === 0 ? -closedGap : closedGap]}>
          {/* black anodized frame around the leaf */}
          <mesh>
            <boxGeometry args={[0.08, 1.9, 0.82]} />
            <meshStandardMaterial color="#0a0a0b" metalness={0.4} roughness={0.4} />
          </mesh>
          {/* dark tinted glass panel — see-through, matches the PSD glass styling */}
          <mesh position={[0.015, 0, 0]}>
            <boxGeometry args={[0.05, 1.68, 0.68]} />
            <meshStandardMaterial
              color="#14171c"
              roughness={0.1}
              metalness={0.12}
              transparent
              opacity={0.6}
              envMapIntensity={0.4}
            />
          </mesh>
          {/* small white hardware dot near the top corner, like the reference photo */}
          <mesh position={[0.05, 0.78, 0.28]}>
            <circleGeometry args={[0.04, 16]} />
            <meshStandardMaterial color="#e8e8e8" metalness={0.6} roughness={0.3} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

/** A passenger's bag + coat caught in the door gap — non-graphic platform incident. */
function StuckObject({ side }: { side: 1 | -1 }) {
  return (
    <group position={[side * 1.55, 0, 0]}>
      {/* duffel bag wedged at the threshold */}
      <mesh position={[0, 0.5, 0]} castShadow rotation={[0, 0, 0.15]}>
        <boxGeometry args={[0.36, 0.34, 0.5]} />
        <meshStandardMaterial color="#7a2230" roughness={0.8} />
      </mesh>
      {/* strap trailing into the door */}
      <mesh position={[-side * 0.12, 0.95, 0]} rotation={[0, 0, side * 0.5]}>
        <boxGeometry args={[0.05, 0.7, 0.08]} />
        <meshStandardMaterial color="#2a2d31" roughness={0.7} />
      </mesh>
      {/* a length of coat hanging out, pinched by the door */}
      <mesh position={[0, 1.1, 0.1]} rotation={[0.1, 0, 0]}>
        <boxGeometry args={[0.08, 0.9, 0.32]} />
        <meshStandardMaterial color="#3b4a63" roughness={0.85} />
      </mesh>
    </group>
  )
}

function Car({
  color,
  accentColor,
  lead,
  doorOpenRef,
  platformSide,
  stuck,
}: {
  color: string
  accentColor: string
  lead?: boolean
  doorOpenRef?: MutableRefObject<number>
  platformSide?: 1 | -1
  stuck?: boolean
}) {
  return (
    <group>
      {/* main body - sleek modern profile matching reference image */}
      <mesh castShadow position={[0, 1.4, 0]}>
        <boxGeometry args={[2.8, 2.3, 5.8]} />
        <meshStandardMaterial color="#d8dce0" metalness={0.55} roughness={0.32} />
      </mesh>
      
      {/* roof - silver metallic finish */}
      <mesh position={[0, 2.68, 0]}>
        <boxGeometry args={[2.7, 0.22, 5.8]} />
        <meshStandardMaterial color="#b5bcc2" metalness={0.65} roughness={0.28} />
      </mesh>
      
      {/* prominent horizontal blue stripe - main accent (like reference image) */}
      <mesh position={[0, 1.4, 0]}>
        <boxGeometry args={[2.95, 0.4, 5.8]} />
        <meshStandardMaterial 
          color={accentColor} 
          emissive={accentColor} 
          emissiveIntensity={0.35}
          metalness={0.65} 
          roughness={0.3} 
        />
      </mesh>
      
      {/* upper window band - left side */}
      <mesh position={[1.43, 2.15, 0]}>
        <boxGeometry args={[0.07, 0.85, 5.3]} />
        <meshStandardMaterial 
          color="#0f1e2e" 
          metalness={0.8} 
          roughness={0.1} 
          emissive="#1a3a55" 
          emissiveIntensity={0.3} 
        />
      </mesh>
      
      {/* upper window band - right side */}
      <mesh position={[-1.43, 2.15, 0]}>
        <boxGeometry args={[0.07, 0.85, 5.3]} />
        <meshStandardMaterial 
          color="#0f1e2e" 
          metalness={0.8} 
          roughness={0.1} 
          emissive="#1a3a55" 
          emissiveIntensity={0.3} 
        />
      </mesh>
      
      {/* lower body panel - gray aluminum */}
      <mesh position={[0, 0.5, 0]}>
        <boxGeometry args={[2.7, 0.65, 5.8]} />
        <meshStandardMaterial color="#9aa2a8" roughness={0.6} metalness={0.2} />
      </mesh>
      
      {/* animated sliding doors on both sides (open when docked at the platform) */}
      {doorOpenRef ? (
        <>
          <SlidingDoor side={1} doorOpenRef={doorOpenRef} accentColor={accentColor} />
          <SlidingDoor side={-1} doorOpenRef={doorOpenRef} accentColor={accentColor} />
        </>
      ) : (
        // static door seams for non-docking trains
        [1.1, -1.1].map((sx) => (
          <mesh key={`door-${sx}`} position={[sx, 1.4, 0]}>
            <boxGeometry args={[0.75, 2.1, 0.04]} />
            <meshStandardMaterial color="#c5cdd3" metalness={0.5} roughness={0.35} />
          </mesh>
        ))
      )}

      {/* object caught in the platform-side door of the lead car */}
      {lead && stuck && platformSide && <StuckObject side={platformSide} />}
      
      {lead && (
        <>
          {/* front nose - aerodynamic design */}
          <mesh position={[0, 1.4, 2.92]}>
            <boxGeometry args={[2.8, 2.3, 0.2]} />
            <meshStandardMaterial color="#d8dce0" metalness={0.55} roughness={0.32} />
          </mesh>
          
          {/* front windscreen - large and highly reflective like reference */}
          <mesh position={[0, 1.75, 2.88]}>
            <planeGeometry args={[2.5, 1.5]} />
            <meshStandardMaterial 
              color="#050d15" 
              metalness={0.88} 
              roughness={0.04} 
              emissive="#0a1a2f" 
              emissiveIntensity={0.4} 
            />
          </mesh>
          
          {/* front blue stripe on nose */}
          <mesh position={[0, 1.4, 2.94]}>
            <boxGeometry args={[2.95, 0.4, 0.12]} />
            <meshStandardMaterial 
              color={accentColor} 
              emissive={accentColor} 
              emissiveIntensity={0.35}
              metalness={0.68}
              roughness={0.28}
            />
          </mesh>
          
          {/* bright front light panel - main light array */}
          <mesh position={[0, 0.5, 2.94]}>
            <boxGeometry args={[2.3, 0.55, 0.08]} />
            <meshStandardMaterial 
              color="#f8fafb" 
              emissive="#f5f8fa" 
              emissiveIntensity={3.0}
              metalness={0.5}
              roughness={0.18}
            />
          </mesh>
          
          {/* left main headlight */}
          <mesh position={[0.85, 0.65, 2.95]}>
            <circleGeometry args={[0.22, 16]} />
            <meshStandardMaterial 
              color="#fffcf5" 
              emissive="#fffef8" 
              emissiveIntensity={2.9}
              metalness={0.6}
            />
          </mesh>
          
          {/* right main headlight */}
          <mesh position={[-0.85, 0.65, 2.95]}>
            <circleGeometry args={[0.22, 16]} />
            <meshStandardMaterial 
              color="#fffcf5" 
              emissive="#fffef8" 
              emissiveIntensity={2.9}
              metalness={0.6}
            />
          </mesh>
        </>
      )}
    </group>
  )
}

export function Train({
  x,
  stopped,
  color = "#e7e9ec",
  accentColor = "#1d4ed8",
  cars = 3,
  speedKmh,
  cruise = 7,
  direction = -1,
  loopLimit = 70,
  startZ = 0,
  label,
  dock = false,
  dockZ = 0,
  platformSide = -1,
  stuckObject = false,
  track,
  dwellSeconds = 6,
  resetSignal,
}: TrainProps) {
  const ref = useRef<Group>(null)
  const { updateTrainDoor, updateTrainPhase } = useDoorSync()
  // cruise speed in scene units — from real km/h when provided.
  const cruiseScene = speedKmh !== undefined ? speedKmh * KMH_TO_SCENE : cruise
  const speed = useRef(cruiseScene)
  const carLen = 5.9

  // door open amount (0 closed → 1 open) shared by every car, animated each frame
  const doorOpen = useRef(0)
  // automatic platform cycle phase for docking trains
  const phase = useRef<"arriving" | "dwell" | "leaving">("arriving")
  const dwellT = useRef(0)
  const DWELL_SECONDS = dwellSeconds
  const lastReportedDoor = useRef(-1)
  const lastReportedPhase = useRef<"arriving" | "dwell" | "leaving" | "idle">("idle")

  // Report door state to context for PSD synchronization
  useEffect(() => {
    if (track && dock) {
      const interval = setInterval(() => {
        if (Math.abs(doorOpen.current - lastReportedDoor.current) > 0.025) {
          lastReportedDoor.current = doorOpen.current
          updateTrainDoor(track, doorOpen.current)
        }
        if (phase.current !== lastReportedPhase.current) {
          lastReportedPhase.current = phase.current
          updateTrainPhase(track, phase.current)
        }
      }, 50)
      return () => clearInterval(interval)
    }
  }, [track, dock, updateTrainDoor, updateTrainPhase])

  // Whenever the ESP is reset (resetSignal bumps), force the dock cycle back
  // to "arriving" so a train frozen mid-cycle (e.g. stuck mid-dwell) reliably
  // resumes moving rather than idling out a stale dwell timer.
  useEffect(() => {
    if (resetSignal === undefined) return
    if (dock) {
      dwellT.current = 0
      doorOpen.current = 0
      const g = ref.current
      // Only resume an "arriving" approach if the train genuinely hasn't
      // reached the platform yet on this lap (dist still meaningfully
      // positive). If it's already at/past the dock point, treat it as
      // "leaving" so it just continues cruising normally — forcing
      // "arriving" unconditionally here used to make the train creep at a
      // near-stall 0.5 u/s forever, since it can never "arrive" at a point
      // that's now behind it (this was the post-reset lagging bug).
      const dist = g ? (dockZ - g.position.z) * direction : 1
      phase.current = dist > 0.5 ? "arriving" : "leaving"
    }
    // Ease back up from rest instead of snapping straight to cruise speed —
    // the "arriving"/cruise branches below already ramp speed up smoothly,
    // so starting from 0 here is what actually makes the post-reset restart
    // glide instead of jump-cutting to full speed.
    speed.current = 0
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetSignal])

  useFrame((_, dtRaw) => {
    const g = ref.current
    if (!g) return
    const dt = Math.min(dtRaw, 0.05)
    const lerp = (cur: number, target: number, k: number) => cur + (target - cur) * Math.min(1, dt * k)

    // Emergency hold (manual brake / ESP) overrides everything: brake to rest,
    // keep doors shut while the train is stranded.
    if (stopped) {
      if (speedKmh !== undefined) {
        speed.current = Math.max(0, speed.current - EB_DECEL_SCENE * dt)
      } else {
        speed.current = lerp(speed.current, 0, 6)
        if (speed.current < 0.01) speed.current = 0
      }
      doorOpen.current = lerp(doorOpen.current, 0, 3)
      g.position.z += speed.current * dt * direction
      return
    }

    if (dock) {
      // automatic arrive → open doors → dwell → close → depart cycle
      if (phase.current === "arriving") {
        doorOpen.current = lerp(doorOpen.current, 0, 4)
        const dist = (dockZ - g.position.z) * direction // distance still to travel
        const target = Math.min(cruiseScene, Math.max(0.5, dist * 1.1))
        speed.current = lerp(speed.current, target, 3)
        g.position.z += speed.current * dt * direction
        if (dist <= 0.06) {
          g.position.z = dockZ
          speed.current = 0
          dwellT.current = 0
          phase.current = "dwell"
        }
      } else if (phase.current === "dwell") {
        speed.current = 0
        doorOpen.current = lerp(doorOpen.current, 1, 2)
        dwellT.current += dt
        if (dwellT.current > DWELL_SECONDS) phase.current = "leaving"
      } else {
        // leaving: shut the doors, then pull out and loop back to approach again
        doorOpen.current = lerp(doorOpen.current, 0, 3)
        if (doorOpen.current < 0.04) {
          speed.current = lerp(speed.current, cruiseScene, 2)
          g.position.z += speed.current * dt * direction
          if (Math.abs(g.position.z) > loopLimit) {
            g.position.z = -loopLimit * direction
            phase.current = "arriving"
          }
        }
      }
      return
    }

    // non-docking train: smooth cruise + endless loop, doors stay shut.
    // Always ease toward cruise speed (never snap) so a restart from rest
    // (e.g. right after an ESP reset) accelerates smoothly instead of
    // jump-cutting straight to full speed.
    speed.current = lerp(speed.current, cruiseScene, 2.5)
    g.position.z += speed.current * dt * direction
    if (g.position.z > loopLimit) g.position.z = -loopLimit
    if (g.position.z < -loopLimit) g.position.z = loopLimit
  })

  return (
    <group ref={ref} position={[x, 0, startZ]}>
      {/* orient the consist so the lead car (windscreen at +z) points in the travel direction */}
      <group rotation={[0, direction === 1 ? 0 : Math.PI, 0]}>
        {Array.from({ length: cars }).map((_, i) => (
          <group key={i} position={[0, 0, (i - (cars - 1) / 2) * carLen]}>
            <Car
              color={color}
              accentColor={accentColor}
              lead={i === 0}
              doorOpenRef={dock ? doorOpen : undefined}
              platformSide={platformSide}
              stuck={stuckObject}
            />
          </group>
        ))}
      </group>
      {label && (
        <Text position={[0, 3.2, 0]} fontSize={0.5} color={accentColor} anchorX="center" anchorY="middle">
          {label}
        </Text>
      )}
    </group>
  )
}
