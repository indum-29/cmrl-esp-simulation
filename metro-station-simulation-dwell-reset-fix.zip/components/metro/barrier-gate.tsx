"use client"

import { useRef, type MutableRefObject } from "react"
import { useFrame } from "@react-three/fiber"
import type { Group, Mesh } from "three"

interface BarrierGateProps {
  x: number
  z: number
  barrierOpenRef: MutableRefObject<number>
  accent?: string
}

/**
 * Rotating arm barrier gate that lifts up when train is in dwell phase.
 * Red and white striped arm rotates around a pivot point at the base.
 */
export function BarrierGate({ x, z, barrierOpenRef, accent = "#ff0000" }: BarrierGateProps) {
  const armRef = useRef<Mesh>(null)
  const targetRotation = useRef(0)
  const currentRotation = useRef(0)

  // Maximum rotation angle when fully open (radians)
  const MAX_ROTATION = Math.PI / 2 + 0.2 // ~100 degrees up

  useFrame(() => {
    if (!armRef.current) return

    // Convert 0-1 open state to rotation angle
    targetRotation.current = barrierOpenRef.current * MAX_ROTATION

    // Smoothly animate rotation toward target
    currentRotation.current += (targetRotation.current - currentRotation.current) * 0.08

    // Apply rotation around the z-axis (pivot at base)
    armRef.current.rotation.z = currentRotation.current
  })

  return (
    <group position={[x, 1.15, z]}>
      {/* base pedestal */}
      <mesh position={[0, 0.3, 0]} castShadow>
        <boxGeometry args={[0.5, 0.6, 0.5]} />
        <meshStandardMaterial color="#4a4f55" metalness={0.4} roughness={0.6} />
      </mesh>

      {/* pivot post */}
      <mesh position={[0, 0.45, 0]} castShadow>
        <cylinderGeometry args={[0.15, 0.15, 0.3, 8]} />
        <meshStandardMaterial color="#5a6269" metalness={0.5} roughness={0.5} />
      </mesh>

      {/* rotating arm barrier ref point */}
      <group ref={armRef} position={[0, 0.6, 0]}>
        {/* main arm body - red and white striped */}
        <mesh position={[0.8, 0, 0]} castShadow>
          <boxGeometry args={[1.6, 0.2, 0.4]} />
          <meshStandardMaterial color={accent} metalness={0.3} roughness={0.4} />
        </mesh>

        {/* white diagonal stripes for visibility */}
        <mesh position={[0.3, 0.11, 0]} rotation={[0, 0, Math.PI / 6]}>
          <boxGeometry args={[0.35, 0.08, 0.42]} />
          <meshStandardMaterial color="#ffffff" metalness={0.2} roughness={0.3} />
        </mesh>

        <mesh position={[0.8, 0.11, 0]} rotation={[0, 0, Math.PI / 6]}>
          <boxGeometry args={[0.35, 0.08, 0.42]} />
          <meshStandardMaterial color="#ffffff" metalness={0.2} roughness={0.3} />
        </mesh>

        <mesh position={[1.3, 0.11, 0]} rotation={[0, 0, Math.PI / 6]}>
          <boxGeometry args={[0.35, 0.08, 0.42]} />
          <meshStandardMaterial color="#ffffff" metalness={0.2} roughness={0.3} />
        </mesh>

        {/* end cap */}
        <mesh position={[1.6, 0, 0]} castShadow>
          <boxGeometry args={[0.2, 0.25, 0.5]} />
          <meshStandardMaterial color="#2a2d31" metalness={0.6} roughness={0.3} />
        </mesh>
      </group>

      {/* status indicator - green when open */}
      {barrierOpenRef.current > 0.7 && (
        <mesh position={[0, 0.15, 0.3]}>
          <boxGeometry args={[0.08, 0.08, 0.08]} />
          <meshStandardMaterial color="#00ff00" emissive="#00ff00" emissiveIntensity={0.9} />
        </mesh>
      )}
    </group>
  )
}
