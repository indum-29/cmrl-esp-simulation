"use client"

import { useMemo, useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { Text } from "@react-three/drei"
import type { Group } from "three"
import * as THREE from "three"

/* ------------------------------------------------------------------ */
/* Track: rails, sleepers, third rail, track bed                       */
/* ------------------------------------------------------------------ */

export function Track({
  x = 0,
  length = 120,
  gauge = 1.4,
}: {
  x?: number
  length?: number
  gauge?: number
}) {
  const sleepers = useMemo(() => {
    const arr: number[] = []
    for (let z = -length / 2; z <= length / 2; z += 1.4) arr.push(z)
    return arr
  }, [length])
  const sleeperMatrices = useMemo(
    () => sleepers.map((z) => new THREE.Matrix4().makeTranslation(0, -0.04, z)),
    [sleepers],
  )

  return (
    <group position={[x, 0, 0]}>
      {/* ballast / track bed */}
      <mesh receiveShadow position={[0, -0.18, 0]}>
        <boxGeometry args={[gauge + 1.1, 0.25, length]} />
        <meshStandardMaterial color="#2b2b2e" roughness={1} />
      </mesh>

      {/* sleepers batched into one draw call to keep long underground tracks smooth */}
      <instancedMesh
        args={[undefined, undefined, sleeperMatrices.length]}
        castShadow
        receiveShadow
        ref={(mesh) => {
          if (!mesh) return
          sleeperMatrices.forEach((matrix, index) => mesh.setMatrixAt(index, matrix))
          mesh.instanceMatrix.needsUpdate = true
        }}
      >
        <boxGeometry args={[gauge + 0.7, 0.1, 0.32]} />
        <meshStandardMaterial color="#4a4640" roughness={0.95} />
      </instancedMesh>

      {/* two running rails (weathered steel) */}
      {[-gauge / 2, gauge / 2].map((rx) => (
        <mesh key={rx} position={[rx, 0.06, 0]} castShadow>
          <boxGeometry args={[0.12, 0.16, length]} />
          <meshStandardMaterial color="#9a9aa0" metalness={0.9} roughness={0.45} />
        </mesh>
      ))}

      {/* third / power rail */}
      <mesh position={[gauge / 2 + 0.55, 0.02, 0]}>
        <boxGeometry args={[0.1, 0.12, length]} />
        <meshStandardMaterial color="#6b5a2a" metalness={0.6} roughness={0.6} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Track circuit glow — visualises the protected / occupied zone       */
/* ------------------------------------------------------------------ */

export function TrackCircuit({
  x = 0,
  z = 0,
  length = 120,
  width = 2.4,
  state,
  label,
  labelRotation = 0,
}: {
  x?: number
  z?: number
  length?: number
  width?: number
  state: "clear" | "armed" | "occupied"
  label?: string
  labelRotation?: number
}) {
  const color = state === "occupied" ? "#ff2d2d" : state === "armed" ? "#ffb020" : "#1fb6ff"
  const intensity = state === "occupied" ? 0.6 : state === "armed" ? 0.36 : 0.16
  return (
    <group>
      {/* circuit glow zone */}
      <mesh position={[x, -0.28, z]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[width, length]} />
        <meshBasicMaterial color={color} transparent opacity={intensity} />
      </mesh>
      {/* boundary insulated-joint markers at each end of the segment */}
      {[z - length / 2, z + length / 2].map((bz) => (
        <mesh key={bz} position={[x, -0.22, bz]}>
          <boxGeometry args={[width + 0.3, 0.06, 0.18]} />
          <meshStandardMaterial color="#f4fbff" emissive={color} emissiveIntensity={0.8} />
        </mesh>
      ))}
      {label && (
        <Text
          position={[x, 0.02, z]}
          rotation={[-Math.PI / 2, 0, labelRotation]}
          fontSize={1.1}
          color={color}
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.04}
          outlineColor="#04121f"
        >
          {label}
        </Text>
      )}
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Platform with tactile edge strip                                    */
/* ------------------------------------------------------------------ */

export function Platform({
  x,
  width = 5,
  length = 60,
  height = 1.1,
  edgeSide = 1,
  color = "#c7c4bd",
}: {
  x: number
  width?: number
  length?: number
  height?: number
  edgeSide?: 1 | -1
  color?: string
}) {
  const edgeX = x + (edgeSide * width) / 2
  return (
    <group>
      {/* slab */}
      <mesh position={[x, height / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[width, height, length]} />
        <meshStandardMaterial color={color} roughness={0.9} />
      </mesh>
      {/* deck top */}
      <mesh position={[x, height + 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[width, length]} />
        <meshStandardMaterial color="#d9d6cf" roughness={0.85} />
      </mesh>
      {/* yellow tactile warning strip along the edge */}
      <mesh position={[edgeX - edgeSide * 0.3, height + 0.012, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.45, length]} />
        <meshStandardMaterial color="#f4c430" emissive="#5a4500" emissiveIntensity={0.25} roughness={0.7} />
      </mesh>
      {/* edge nosing */}
      <mesh position={[edgeX, height - 0.02, 0]}>
        <boxGeometry args={[0.08, 0.12, length]} />
        <meshStandardMaterial color="#222" roughness={0.6} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Safety railing (painted metal balusters)                            */
/* ------------------------------------------------------------------ */

export function Railing({
  x,
  length = 60,
  y = 1.1,
  color = "#1d4ed8",
}: {
  x: number
  length?: number
  y?: number
  color?: string
}) {
  const posts = useMemo(() => {
    const arr: number[] = []
    for (let z = -length / 2; z <= length / 2; z += 2) arr.push(z)
    return arr
  }, [length])
  return (
    <group position={[x, y, 0]}>
      <mesh position={[0, 1, 0]}>
        <boxGeometry args={[0.06, 0.06, length]} />
        <meshStandardMaterial color={color} metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.55, 0]}>
        <boxGeometry args={[0.05, 0.05, length]} />
        <meshStandardMaterial color={color} metalness={0.5} roughness={0.4} />
      </mesh>
      {posts.map((z) => (
        <mesh key={z} position={[0, 0.5, z]}>
          <cylinderGeometry args={[0.03, 0.03, 1, 8]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.4} />
        </mesh>
      ))}
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* CCTV camera on a bracket                                            */
/* ------------------------------------------------------------------ */

export function CCTV({
  position,
  rotation = [0, 0, 0],
}: {
  position: [number, number, number]
  rotation?: [number, number, number]
}) {
  return (
    <group position={position} rotation={rotation}>
      <mesh position={[0, 0, -0.25]}>
        <boxGeometry args={[0.05, 0.05, 0.5]} />
        <meshStandardMaterial color="#3a3a3a" metalness={0.6} roughness={0.5} />
      </mesh>
      <mesh castShadow>
        <boxGeometry args={[0.18, 0.16, 0.4]} />
        <meshStandardMaterial color="#e8e8e8" roughness={0.4} />
      </mesh>
      <mesh position={[0, 0, 0.22]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.06, 0.07, 0.08, 16]} />
        <meshStandardMaterial color="#0b0b0b" metalness={0.3} roughness={0.2} />
      </mesh>
      {/* status LED */}
      <mesh position={[0.05, 0.09, 0.05]}>
        <sphereGeometry args={[0.012, 8, 8]} />
        <meshStandardMaterial color="#ff3030" emissive="#ff3030" emissiveIntensity={2} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Passenger Information Display (PIDS)                                 */
/* ------------------------------------------------------------------ */

export function PIDS({
  position,
  rotation = [0, 0, 0],
  line1 = "NEXT TRAIN",
  line2 = "2 MIN",
  alarm = false,
}: {
  position: [number, number, number]
  rotation?: [number, number, number]
  line1?: string
  line2?: string
  alarm?: boolean
}) {
  return (
    <group position={position} rotation={rotation}>
      {/* housing */}
      <mesh castShadow>
        <boxGeometry args={[2.8, 1.1, 0.14]} />
        <meshStandardMaterial color="#0c0c0f" roughness={0.5} />
      </mesh>
      {/* screen — no red on alarm, standard colors always */}
      <mesh position={[0, 0, 0.08]}>
        <planeGeometry args={[2.6, 0.92]} />
        <meshStandardMaterial
          color="#04121f"
          emissive="#0a2a44"
          emissiveIntensity={0.4}
        />
      </mesh>
      <Text position={[0, 0.22, 0.09]} fontSize={0.24} color="#ffcf3f" anchorX="center" anchorY="middle">
        {line1}
      </Text>
      <Text position={[0, -0.20, 0.09]} fontSize={0.26} color="#56d8ff" anchorX="center" anchorY="middle">
        {line2}
      </Text>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Hanging / standing signboard                                        */
/* ------------------------------------------------------------------ */

export function Signboard({
  position,
  rotation = [0, 0, 0],
  label,
  color = "#0b5d3b",
  width = 2.4,
}: {
  position: [number, number, number]
  rotation?: [number, number, number]
  label: string
  color?: string
  width?: number
}) {
  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow>
        <boxGeometry args={[width, 0.55, 0.06]} />
        <meshStandardMaterial color={color} roughness={0.5} />
      </mesh>
      <Text position={[0, 0, 0.04]} fontSize={0.26} color="#ffffff" anchorX="center" anchorY="middle" maxWidth={width - 0.2}>
        {label}
      </Text>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Lighting / electrical pole                                          */
/* ------------------------------------------------------------------ */

export function LightPole({
  position,
  height = 4.5,
}: {
  position: [number, number, number]
  height?: number
}) {
  return (
    <group position={position}>
      <mesh castShadow position={[0, height / 2, 0]}>
        <cylinderGeometry args={[0.08, 0.1, height, 12]} />
        <meshStandardMaterial color="#5a5a5e" metalness={0.6} roughness={0.5} />
      </mesh>
      <mesh position={[0, height, 0]}>
        <boxGeometry args={[0.8, 0.12, 0.3]} />
        <meshStandardMaterial color="#3a3a3e" />
      </mesh>
      <mesh position={[0, height - 0.08, 0]}>
        <boxGeometry args={[0.7, 0.04, 0.22]} />
        <meshStandardMaterial color="#fff7e0" emissive="#fff2cc" emissiveIntensity={1.4} />
      </mesh>
      <pointLight position={[0, height - 0.2, 0]} intensity={12} distance={14} color="#fff2d6" castShadow={false} />
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Tube light strip (underground)                                      */
/* ------------------------------------------------------------------ */

export function StripLight({
  position,
  length = 3,
}: {
  position: [number, number, number]
  length?: number
}) {
  return (
    <group position={position}>
      <mesh>
        <boxGeometry args={[0.25, 0.08, length]} />
        <meshStandardMaterial color="#f4fbff" emissive="#dff1ff" emissiveIntensity={1.6} />
      </mesh>
      <pointLight intensity={6} distance={10} color="#e9f4ff" />
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Fallen person marker (appears when intrusion is triggered)          */
/* ------------------------------------------------------------------ */

export function FallenPerson({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 0.12, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <capsuleGeometry args={[0.18, 0.8, 4, 8]} />
        <meshStandardMaterial color="#e85d1a" roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.2, 0.55]} castShadow>
        <sphereGeometry args={[0.16, 16, 16]} />
        <meshStandardMaterial color="#e8b48a" roughness={0.8} />
      </mesh>
      {/* alarm ring */}
      <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.7, 0.95, 32]} />
        <meshBasicMaterial color="#ff2d2d" transparent opacity={0.7} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Standing passenger (idle commuter on the platform)                  */
/* ------------------------------------------------------------------ */

export function Passenger({
  position,
  color = "#3b6ea5",
  rotation = 0,
}: {
  position: [number, number, number]
  color?: string
  rotation?: number
}) {
  return (
    <group position={position} rotation={[0, rotation, 0]}>
      {/* legs */}
      <mesh position={[0, 0.32, 0]} castShadow>
        <boxGeometry args={[0.26, 0.46, 0.2]} />
        <meshStandardMaterial color="#2c2f36" roughness={0.9} />
      </mesh>
      {/* torso */}
      <mesh position={[0, 0.78, 0]} castShadow>
        <capsuleGeometry args={[0.17, 0.4, 4, 10]} />
        <meshStandardMaterial color={color} roughness={0.8} />
      </mesh>
      {/* head */}
      <mesh position={[0, 1.18, 0]} castShadow>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshStandardMaterial color="#e8b48a" roughness={0.8} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Crowd: a deterministic scatter of passengers along a platform strip */
/* ------------------------------------------------------------------ */

export function Crowd({
  count = 10,
  xRange,
  zRange,
  y,
  facing = 0,
}: {
  count?: number
  xRange: [number, number]
  zRange: [number, number]
  y: number
  facing?: number
}) {
  const palette = ["#3b6ea5", "#b5483a", "#3f7d57", "#caa23b", "#5a5f6b", "#8a5a9c"]
  const people = useMemo(() => {
    const arr: { pos: [number, number, number]; color: string; rot: number }[] = []
    // deterministic pseudo-random so it stays stable across renders
    let seed = 7
    const rnd = () => {
      seed = (seed * 9301 + 49297) % 233280
      return seed / 233280
    }
    for (let i = 0; i < count; i++) {
      const x = xRange[0] + rnd() * (xRange[1] - xRange[0])
      const z = zRange[0] + rnd() * (zRange[1] - zRange[0])
      arr.push({
        pos: [x, y, z],
        color: palette[Math.floor(rnd() * palette.length)],
        rot: facing + (rnd() - 0.5) * 0.8,
      })
    }
    return arr
  }, [count, xRange, zRange, y, facing])

  return (
    <group>
      {people.map((p, i) => (
        <Passenger key={i} position={p.pos} color={p.color} rotation={p.rot} />
      ))}
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Platform controller — staff member who presses the ESP plunger      */
/* ------------------------------------------------------------------ */

export function PlatformController({
  position,
  rotation = 0,
  active = false,
  onClick,
}: {
  position: [number, number, number]
  rotation?: number
  active?: boolean
  onClick?: () => void
}) {
  return (
    <group
      position={position}
      rotation={[0, rotation, 0]}
      scale={1.0}
      onClick={
        onClick
          ? (e) => {
              e.stopPropagation()
              onClick()
            }
          : undefined
      }
      onPointerOver={(e) => {
        e.stopPropagation()
        if (onClick) document.body.style.cursor = "pointer"
      }}
      onPointerOut={() => {
        document.body.style.cursor = "auto"
      }}
    >
      {/* legs (dark trousers) */}
      <mesh position={[0, 0.34, 0]} castShadow>
        <boxGeometry args={[0.28, 0.5, 0.22]} />
        <meshStandardMaterial color="#1b2733" roughness={0.9} />
      </mesh>
      {/* hi-vis vest torso */}
      <mesh position={[0, 0.84, 0]} castShadow>
        <capsuleGeometry args={[0.19, 0.44, 4, 12]} />
        <meshStandardMaterial color="#ff7a00" emissive="#ff7a00" emissiveIntensity={0.25} roughness={0.6} />
      </mesh>
      {/* reflective band */}
      <mesh position={[0, 0.82, 0.19]}>
        <boxGeometry args={[0.34, 0.08, 0.02]} />
        <meshStandardMaterial color="#f4fbff" emissive="#dff1ff" emissiveIntensity={0.6} />
      </mesh>
      {/* head */}
      <mesh position={[0, 1.26, 0]} castShadow>
        <sphereGeometry args={[0.16, 16, 16]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      {/* peaked cap */}
      <mesh position={[0, 1.4, 0]} castShadow>
        <cylinderGeometry args={[0.17, 0.18, 0.12, 16]} />
        <meshStandardMaterial color="#15324f" roughness={0.6} />
      </mesh>
      <mesh position={[0, 1.36, 0.18]}>
        <boxGeometry args={[0.3, 0.04, 0.14]} />
        <meshStandardMaterial color="#15324f" roughness={0.6} />
      </mesh>
      {/* pressing arm: raised toward the ESP when active, resting otherwise */}
      <mesh
        position={[0.26, active ? 1.0 : 0.82, active ? 0.22 : 0.05]}
        rotation={[active ? -1.1 : -0.2, 0, active ? -0.5 : -0.2]}
        castShadow
      >
        <capsuleGeometry args={[0.06, 0.42, 4, 8]} />
        <meshStandardMaterial color="#ff7a00" roughness={0.6} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Emergency Stop Plunger (ESP) post                                   */
/* ------------------------------------------------------------------ */

export function EspPost({
  position,
  active,
  onClick,
}: {
  position: [number, number, number]
  active: boolean
  onClick?: () => void
}) {
  return (
    <group position={position}>
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 1.2, 10]} />
        <meshStandardMaterial color="#d0d0d0" metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh
        position={[0, 1.25, 0]}
        onClick={onClick}
        onPointerOver={(e) => {
          e.stopPropagation()
          if (onClick) document.body.style.cursor = "pointer"
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto"
        }}
      >
        <boxGeometry args={[0.32, 0.42, 0.14]} />
        <meshStandardMaterial color="#ffd400" roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.25, 0.09]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 0.06, 16]} />
        <meshStandardMaterial
          color={active ? "#ff2d2d" : "#c0202a"}
          emissive={active ? "#ff2d2d" : "#000000"}
          emissiveIntensity={active ? 1.6 : 0}
        />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Falling person — person falling onto track triggered by ESP         */
/* ------------------------------------------------------------------ */

export function FallingPerson({
  position,
  falling = false,
}: {
  position: [number, number, number]
  falling?: boolean
}) {
  const yOffset = falling ? -1.2 : 0
  
  return (
    <group position={[position[0], position[1] + yOffset, position[2]]}>
      {/* head */}
      <mesh position={[0, 1.1, 0]} castShadow>
        <sphereGeometry args={[0.14, 12, 12]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      {/* torso */}
      <mesh position={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[0.22, 0.45, 0.16]} />
        <meshStandardMaterial color="#4a5a7a" roughness={0.7} />
      </mesh>
      {/* left arm */}
      <mesh position={[-0.18, 0.7, 0]} castShadow>
        <boxGeometry args={[0.08, 0.35, 0.08]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      {/* right arm */}
      <mesh position={[0.18, 0.7, 0]} castShadow>
        <boxGeometry args={[0.08, 0.35, 0.08]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      {/* left leg */}
      <mesh position={[-0.1, 0.2, 0]} castShadow>
        <boxGeometry args={[0.08, 0.4, 0.08]} />
        <meshStandardMaterial color="#1b2733" roughness={0.9} />
      </mesh>
      {/* right leg */}
      <mesh position={[0.1, 0.2, 0]} castShadow>
        <boxGeometry args={[0.08, 0.4, 0.08]} />
        <meshStandardMaterial color="#1b2733" roughness={0.9} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ */
/* Falling hazard — a person AND a piece of trash falling from the     */
/* platform edge onto the track, then settling as a stopped hazard.    */
/* The drop is animated each frame from `startTime` so it looks        */
/* automatic and realistic (short delay, gravity-eased descent).       */
/* ------------------------------------------------------------------ */

/** A small upright/lying figure used for the falling person. */
function FigureBody() {
  return (
    <group>
      {/* head */}
      <mesh position={[0, 1.12, 0]} castShadow>
        <sphereGeometry args={[0.16, 16, 16]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      {/* torso */}
      <mesh position={[0, 0.62, 0]} castShadow>
        <capsuleGeometry args={[0.17, 0.42, 4, 10]} />
        <meshStandardMaterial color="#c0392b" roughness={0.75} />
      </mesh>
      {/* arms */}
      <mesh position={[-0.22, 0.78, 0]} rotation={[0, 0, 0.6]} castShadow>
        <capsuleGeometry args={[0.06, 0.36, 4, 8]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      <mesh position={[0.22, 0.78, 0]} rotation={[0, 0, -0.6]} castShadow>
        <capsuleGeometry args={[0.06, 0.36, 4, 8]} />
        <meshStandardMaterial color="#d9a074" roughness={0.8} />
      </mesh>
      {/* legs */}
      <mesh position={[-0.1, 0.2, 0]} castShadow>
        <boxGeometry args={[0.09, 0.42, 0.1]} />
        <meshStandardMaterial color="#1b2733" roughness={0.9} />
      </mesh>
      <mesh position={[0.1, 0.2, 0]} castShadow>
        <boxGeometry args={[0.09, 0.42, 0.1]} />
        <meshStandardMaterial color="#1b2733" roughness={0.9} />
      </mesh>
    </group>
  )
}

/** A tumbling bag of trash / dropped object. */
function TrashObject() {
  return (
    <group>
      <mesh castShadow>
        <boxGeometry args={[0.3, 0.32, 0.3]} />
        <meshStandardMaterial color="#3f7d57" roughness={0.85} />
      </mesh>
      <mesh position={[0.12, 0.16, 0.05]} castShadow>
        <boxGeometry args={[0.16, 0.14, 0.16]} />
        <meshStandardMaterial color="#caa23b" roughness={0.85} />
      </mesh>
    </group>
  )
}

export function FallingHazard({
  x,
  z,
  groundY = 0.05,
  startTime,
  kind = "both",
}: {
  x: number
  z: number
  /** y of the track surface where the figure comes to rest */
  groundY?: number
  /** performance.now() timestamp when the fall began */
  startTime: number
  /** Which hazard to render — "person-fall" scenarios show only the person, "object-fall" only the object. */
  kind?: "person" | "object" | "both"
}) {
  const personRef = useRef<Group>(null)
  const trashRef = useRef<Group>(null)

  const DELAY = 0.15 // brief pause before the drop reads as "slipping off the edge"
  const FALL = 0.85 // seconds of falling
  const TOP = groundY + 2.3 // start height (platform shoulder height)

  const showPerson = kind === "person" || kind === "both"
  const showObject = kind === "object" || kind === "both"

  useFrame(() => {
    const now = typeof performance !== "undefined" ? performance.now() : Date.now()
    const t = (now - startTime) / 1000

    // person
    const pp = Math.min(1, Math.max(0, (t - DELAY) / FALL))
    const pEase = pp * pp // gravity acceleration
    if (personRef.current) {
      personRef.current.position.y = TOP + (groundY - TOP) * pEase
      // rotate from standing to lying flat on the track as it lands
      personRef.current.rotation.x = (-Math.PI / 2) * Math.min(1, pp * 1.15)
    }

    // trash falls slightly later and lands beside the person
    const tp = Math.min(1, Math.max(0, (t - DELAY - 0.1) / FALL))
    const tEase = tp * tp
    if (trashRef.current) {
      trashRef.current.position.y = TOP - 0.4 + (groundY + 0.12 - (TOP - 0.4)) * tEase
      trashRef.current.rotation.x = tp * Math.PI * 1.2
      trashRef.current.rotation.z = tp * Math.PI
    }
  })

  return (
    <group position={[x, 0, z]}>
      {/* person — only for person-fall scenarios */}
      {showPerson && (
        <group ref={personRef} position={[0, TOP, 0]}>
          <FigureBody />
        </group>
      )}

      {/* trash / dropped object — only for object-fall scenarios, lands toward the platform side */}
      {showObject && (
        <group ref={trashRef} position={[0, TOP - 0.4, 0.5]}>
          <TrashObject />
        </group>
      )}

      {/* pulsing alarm ring marking the hazard zone on the track */}
      <mesh position={[0, groundY - 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.7, 1.0, 40]} />
        <meshBasicMaterial color="#ff2d2d" transparent opacity={0.75} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}
