"use client"

import { useState, useEffect } from "react"
import { useEsp, brakingProfile, type TrackId } from "@/lib/esp-store"
import { useFallingPerson } from "@/lib/falling-person-context"
import { usePlatformESP } from "@/lib/platform-esp-context"
import { useScenario } from "@/lib/scenario-context"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

function StatusDot({ tone }: { tone: "ok" | "warn" | "alarm" }) {
  const color =
    tone === "alarm" ? "bg-red-500" : tone === "warn" ? "bg-amber-400" : "bg-emerald-400"
  return (
    <span className={cn("inline-block size-2.5 rounded-full", color, tone === "alarm" && "animate-pulse")} />
  )
}

function Row({ label, value, tone }: { label: string; value: string; tone?: "alarm" | "warn" | "ok" }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="font-mono text-[10px] uppercase tracking-wide text-muted-foreground">{label}</span>
      <span
        className={cn(
          "font-mono text-[11px] font-semibold tabular-nums",
          tone === "alarm" ? "text-red-400" : tone === "warn" ? "text-amber-300" : tone === "ok" ? "text-emerald-300" : "text-foreground",
        )}
      >
        {value}
      </span>
    </div>
  )
}

function TrainCard({ id }: { id: TrackId }) {
  const { trainStopped, espActive, occupancy, trainSpeedKmh, setSpeed } = useEsp()
  const stopped = trainStopped[id]
  const speed = trainSpeedKmh[id]
  const { stopTime, stopDist } = brakingProfile(speed)
  const tone = occupancy[id] === "occupied" ? "alarm" : stopped ? "warn" : "ok"
  return (
    <div
      className={cn(
        "rounded-md border bg-card/70 p-1.5 transition-colors",
        stopped ? "border-red-500/60" : "border-border",
      )}
    >
      <div className="flex items-center justify-between">
        <span className="font-mono text-xs font-semibold text-foreground">TRAIN {id}</span>
        <StatusDot tone={tone} />
      </div>

      {/* speed selector */}
      <div className="mt-1 flex items-center justify-between gap-1">
        <span className="font-mono text-[9px] uppercase tracking-wide text-muted-foreground">Speed</span>
        <div className="flex items-center gap-0.5">
          <button
            onClick={() => setSpeed(id, speed - 10)}
            disabled={stopped}
            className="size-4 rounded bg-secondary font-mono text-[9px] leading-none text-secondary-foreground transition-colors hover:bg-accent disabled:opacity-40"
            aria-label={`Decrease train ${id} speed`}
          >
            -
          </button>
          <span className="w-12 text-center font-mono text-[9px] font-semibold tabular-nums text-foreground">
            {speed}
          </span>
          <button
            onClick={() => setSpeed(id, speed + 10)}
            disabled={stopped}
            className="size-4 rounded bg-secondary font-mono text-[9px] leading-none text-secondary-foreground transition-colors hover:bg-accent disabled:opacity-40"
            aria-label={`Increase train ${id} speed`}
          >
            +
          </button>
        </div>
      </div>

      <div className="mt-1 space-y-0.5 border-t border-border pt-1">
        <Row label="EB Applied" value={stopped ? "YES" : "NO"} tone={stopped ? "warn" : undefined} />
        <Row label="Stop Time" value={`${stopTime.toFixed(1)}s`} />
        <Row label="Stop Dist" value={`${stopDist.toFixed(0)}m`} />
        <Row label="Status" value={stopped ? "STOPPED" : "RUNNING"} tone={stopped ? "alarm" : "ok"} />
      </div>

      <p className="mt-1 font-mono text-[8px] text-muted-foreground">
        ESP {espActive[id] ? "TRIPPED" : "ARMED"} · TC {occupancy[id] === "occupied" ? "OCC" : "CLR"}
      </p>
    </div>
  )
}

function TrackControls({ id }: { id: TrackId }) {
  const { personFall, emergencyBrake } = useEsp()
  const { triggerFall } = useFallingPerson()
  return (
    <div className="grid grid-cols-2 gap-1">
      <button
        onClick={() => {
          triggerFall(id)
          personFall(id)
        }}
        className="rounded-md bg-amber-500 px-1.5 py-1 font-mono text-[8px] font-semibold text-black transition-colors hover:bg-amber-400"
      >
        FALL {id}
      </button>
      <button
        onClick={() => emergencyBrake(id)}
        className="rounded-md bg-red-600 px-1.5 py-1 font-mono text-[8px] font-semibold text-white transition-colors hover:bg-red-500"
      >
        BRAKE {id}
      </button>
    </div>
  )
}

const BLINK_STYLE = `
  @keyframes espBlink {
    0%, 45% {
      background-color: rgb(220 38 38);
      box-shadow: 0 0 20px rgba(220, 38, 38, 1), inset 0 0 12px rgba(220, 38, 38, 0.6);
    }
    50%, 95% {
      background-color: rgb(100 20 20);
      box-shadow: 0 0 10px rgba(100, 20, 20, 0.5), inset 0 0 6px rgba(100, 20, 20, 0.4);
    }
    100% {
      background-color: rgb(220 38 38);
      box-shadow: 0 0 20px rgba(220, 38, 38, 1), inset 0 0 12px rgba(220, 38, 38, 0.6);
    }
  }
  .esp-blink {
    animation: espBlink 0.6s ease-in-out infinite !important;
  }
  
  @keyframes espGlowBlink {
    0%, 45% {
      background-color: rgb(220 38 38);
      box-shadow: 0 0 30px rgba(220, 38, 38, 0.9), 0 0 50px rgba(220, 38, 38, 0.6), inset 0 0 15px rgba(220, 38, 38, 0.7);
    }
    50%, 95% {
      background-color: rgb(100 20 20);
      box-shadow: 0 0 15px rgba(100, 20, 20, 0.5), 0 0 25px rgba(100, 20, 20, 0.2), inset 0 0 8px rgba(100, 20, 20, 0.4);
    }
    100% {
      background-color: rgb(220 38 38);
      box-shadow: 0 0 30px rgba(220, 38, 38, 0.9), 0 0 50px rgba(220, 38, 38, 0.6), inset 0 0 15px rgba(220, 38, 38, 0.7);
    }
  }
  .esp-glow-blink {
    animation: espGlowBlink 0.6s ease-in-out infinite !important;
  }

  /* Control-room alarm — strong red flashing panel */
  @keyframes scrPanelBlink {
    0%, 49% {
      background-color: rgb(127 29 29);
      border-color: rgb(248 113 113);
      box-shadow: 0 0 26px rgba(239, 68, 68, 0.95), inset 0 0 16px rgba(239, 68, 68, 0.55);
    }
    50%, 100% {
      background-color: rgb(40 8 8);
      border-color: rgb(127 29 29);
      box-shadow: 0 0 6px rgba(239, 68, 68, 0.25);
    }
  }
  .scr-panel-blink {
    animation: scrPanelBlink 0.7s steps(1, end) infinite;
  }
  @keyframes scrTextBlink {
    0%, 49% { opacity: 1; }
    50%, 100% { opacity: 0.2; }
  }
  .scr-text-blink {
    animation: scrTextBlink 0.7s steps(1, end) infinite;
  }

  /* SCR Slide Panel Animation */
  @keyframes scrSlideIn {
    from {
      transform: translateX(-100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  @keyframes scrSlideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(-100%);
      opacity: 0;
    }
  }
  .scr-panel-open {
    animation: scrSlideIn 0.3s cubic-bezier(0.32, 0.72, 0.3, 1);
  }
  .scr-panel-closing {
    animation: scrSlideOut 0.3s cubic-bezier(0.32, 0.72, 0.3, 1);
  }
`

/** Badge for an individual platform ESP sensor (sESP1 / sESP2). */
function EspBadge({ label, active }: { label: string; active: boolean }) {
  return (
    <div
      className={cn(
        "flex flex-1 flex-col items-center gap-0.5 rounded-md border px-2 py-1.5 text-center transition-colors",
        active ? "scr-panel-blink border-red-400 text-red-100" : "border-border bg-secondary/40 text-muted-foreground",
      )}
    >
      <span className="font-mono text-[11px] font-bold tracking-wider">{label}</span>
      <span className={cn("font-mono text-[8px] uppercase tracking-widest", active && "scr-text-blink")}>
        {active ? "ALARM" : "Standby"}
      </span>
    </div>
  )
}

function ScenarioButton({
  type,
  platform,
  label,
  selected,
  onClick,
}: {
  type: "person-fall" | "object-fall" | "train-start"
  platform: TrackId
  label: string
  selected: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-md px-2 py-1.5 font-mono text-[10px] font-semibold uppercase tracking-wide transition-all",
        selected
          ? "border-2 border-blue-500 bg-blue-500/20 text-blue-200 shadow-lg shadow-blue-500/30"
          : "border border-border bg-secondary/60 text-secondary-foreground hover:bg-secondary",
      )}
    >
      {label}
    </button>
  )
}

export function ControlPanel() {
  const { mode, setMode, reset, emergency, trainStopped, emergencyBrake, personFall, start, running } = useEsp()
  const { triggerFall, clearFalls } = useFallingPerson()
  const { espPressed, anyPressed, triggerPlatformESP, clearPlatformESP } = usePlatformESP()
  const { selectedScenario, selectScenario, startScenario, triggerScenario, stopScenario, scenarioActive, isScenarioSelected } = useScenario()
  const [controlRoomOpen, setControlRoomOpen] = useState(false)
  const [trainStatusOpen, setTrainStatusOpen] = useState(false)
  const [blinkingButton, setBlinkingButton] = useState<TrackId | null>(null)
  const [espBlinkActive, setEspBlinkActive] = useState<Record<TrackId, boolean>>({ A: false, B: false })

  // Auto-start the train when component mounts
  useEffect(() => {
    if (!running) {
      start()
    }
  }, [])

  // Handle ESP blink animation (5 seconds when pressed)
  useEffect(() => {
    if (blinkingButton) {
      const timer = setTimeout(() => {
        setBlinkingButton(null)
        setEspBlinkActive((prev) => ({ ...prev, [blinkingButton]: false }))
      }, 5000)
      return () => clearTimeout(timer)
    }
  }, [blinkingButton])

  // Handle Escape key to close SCR panel
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && controlRoomOpen) {
        setControlRoomOpen(false)
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [controlRoomOpen])

  const handleESPClick = (platform: TrackId) => {
    setBlinkingButton(platform)
    setEspBlinkActive((prev) => ({ ...prev, [platform]: true }))
    triggerPlatformESP(platform) // latch SCR alarm + alert to controller room
    emergencyBrake(platform) // ESP plunger applies the emergency brake
  }

  const handleFall = (platform: TrackId, kind: "person" | "object" | "both" = "both") => {
    triggerFall(platform, kind) // animate only the selected hazard type dropping onto the track
    personFall(platform) // raise the intrusion / track-circuit-occupied alarm
  }

  const handleStartScenario = () => {
    if (selectedScenario) {
      if (!running) start() // Start simulation if not running
      if (selectedScenario.type === "train-start") {
        // For train-start scenario, start the simulation and trigger scenario
        startScenario()
      } else {
        // For person-fall and object-fall scenarios, trigger only that hazard type
        handleFall(selectedScenario.platform, selectedScenario.type === "person-fall" ? "person" : "object")
        startScenario()
      }
    }
  }

  const handleResetAll = () => {
    reset()
    clearPlatformESP()
    clearFalls()
    stopScenario()
    start() // Restart the train after reset
  }

  const handleScenarioClick = (type: "person-fall" | "object-fall" | "train-start", platform: TrackId) => {
    selectScenario(type, platform)
    // For train-start, start the train movement
    if (type === "train-start") {
      if (!running) start()
    }
  }

  /** Person-fall / object-fall buttons trigger the incident on a single click —
   *  no separate "select then press START" step needed. Each button only ever
   *  drops its own hazard type ("person" or "object"), never both, and a click
   *  on the opposite button for the same platform immediately swaps the hazard
   *  shown on the track. */
  const handlePersonOrObjectClick = (type: "person-fall" | "object-fall", platform: TrackId) => {
    if (!running) start()
    const kind: "person" | "object" = type === "person-fall" ? "person" : "object"
    handleFall(platform, kind)
    triggerScenario(type, platform)
  }

  const anyStopped = trainStopped.A || trainStopped.B

  return (
    <>
      <style>{BLINK_STYLE}</style>
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3 sm:p-5">
        {/* Top bar */}
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex flex-col gap-2">
            {/* Title */}
            <div className="pointer-events-auto rounded-lg border border-border bg-card/80 px-4 py-3 backdrop-blur-md">
              <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                Metro ESP Training Simulator
              </p>
              <h1 className="text-balance text-lg font-semibold text-foreground sm:text-xl">
                {mode === "elevated" ? "Elevated Station — Shared Risk Zone" : "Underground Station — Isolated Tunnels"}
              </h1>
            </div>

            {/* Instructor Controls: Scenario Selection */}
            {mode === "elevated" ? (
              <div className="pointer-events-auto flex flex-col gap-2 rounded-lg border border-border bg-card/80 px-3 py-2.5 backdrop-blur-md w-72">
                <div className="flex items-center justify-between pb-2 border-b border-border">
                  <p className="font-mono text-[8px] uppercase tracking-widest text-muted-foreground font-semibold">
                    Training Scenarios
                  </p>
                  <span className="font-mono text-[9px] text-blue-300">
                    {selectedScenario 
                      ? `${selectedScenario.type === "person-fall" ? "Person" : "Object"} on Platform ${selectedScenario.platform}`
                      : "None Selected"}
                  </span>
                </div>

                {/* Status indicator */}
                <div className="flex items-center gap-2">
                  <StatusDot tone={scenarioActive ? "alarm" : "ok"} />
                  <span className="font-mono text-[7px] uppercase tracking-widest text-muted-foreground">
                    {scenarioActive ? "⚠ Scenario Active" : "Normal"}
                  </span>
                </div>

                {/* Scenario Active Indicator */}
                {scenarioActive && (
                  <div className="rounded-md border border-blue-500/40 bg-blue-600/20 px-2 py-1 text-center">
                    <p className="font-mono text-[8px] font-bold uppercase tracking-widest text-blue-300">
                      Scenario Active
                    </p>
                  </div>
                )}

                {/* Scenario Button Grid - 2x2 layout */}
                <div className="grid grid-cols-2 gap-1.5">
                  <ScenarioButton
                    type="person-fall"
                    platform="A"
                    label="Person Falls\nPlatform 1"
                    selected={isScenarioSelected("person-fall", "A")}
                    onClick={() => handlePersonOrObjectClick("person-fall", "A")}
                  />
                  <ScenarioButton
                    type="object-fall"
                    platform="A"
                    label="Object Falls\nPlatform 1"
                    selected={isScenarioSelected("object-fall", "A")}
                    onClick={() => handlePersonOrObjectClick("object-fall", "A")}
                  />
                  <ScenarioButton
                    type="person-fall"
                    platform="B"
                    label="Person Falls\nPlatform 2"
                    selected={isScenarioSelected("person-fall", "B")}
                    onClick={() => handlePersonOrObjectClick("person-fall", "B")}
                  />
                  <ScenarioButton
                    type="object-fall"
                    platform="B"
                    label="Object Falls\nPlatform 2"
                    selected={isScenarioSelected("object-fall", "B")}
                    onClick={() => handlePersonOrObjectClick("object-fall", "B")}
                  />
                </div>

                {/* Large ESP Action Buttons */}
                <div className="flex flex-col gap-1 border-t border-border pt-2">
                  <button
                    onClick={() => handlePersonOrObjectClick("person-fall", "A")}
                    className={cn(
                      "rounded bg-red-600 px-2 py-2 font-mono text-[8px] font-bold text-white transition-all hover:bg-red-500 w-full",
                      isScenarioSelected("person-fall", "A") && "esp-glow-blink border border-red-300",
                    )}
                  >
                    ESP 1
                  </button>
                  <button
                    onClick={() => handlePersonOrObjectClick("person-fall", "B")}
                    className={cn(
                      "rounded bg-red-600 px-2 py-2 font-mono text-[8px] font-bold text-white transition-all hover:bg-red-500 w-full",
                      isScenarioSelected("person-fall", "B") && "esp-glow-blink border border-red-300",
                    )}
                  >
                    ESP 2
                  </button>
                </div>

                {/* Reset button */}
                <button
                  onClick={handleResetAll}
                  className="w-full rounded-md border border-border bg-secondary px-2 py-1 font-mono text-[7px] font-semibold uppercase tracking-widest text-secondary-foreground transition-colors hover:bg-accent"
                >
                  Reset
                </button>

                <p className="font-mono text-[7px] leading-snug text-muted-foreground text-center">
                  Click scenario buttons or ESP buttons to trigger incidents.
                </p>
              </div>
            ) : (
              <div className="pointer-events-auto flex flex-col gap-2.5 rounded-lg border border-border bg-card/80 px-3 py-2.5 backdrop-blur-md">
                <div className="flex items-center justify-between">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Training Scenarios</p>
                  {selectedScenario && (
                    <span className="font-mono text-[9px] text-blue-300">
                      {selectedScenario.type === "person-fall" ? "Person" : "Object"} on Platform {selectedScenario.platform}
                    </span>
                  )}
                </div>

                {/* Scenario Button Grid */}
                <div className="grid grid-cols-4 gap-1.5">
                  <ScenarioButton
                    type="train-start"
                    platform="A"
                    label="Start Train\nMovement"
                    selected={isScenarioSelected("train-start", "A")}
                    onClick={() => handleScenarioClick("train-start", "A")}
                  />
                </div>

                <Button
                  onClick={handleStartScenario}
                  disabled={!selectedScenario || scenarioActive}
                  className={cn(
                    "w-full font-mono text-sm font-bold tracking-wide",
                    selectedScenario && !scenarioActive
                      ? "bg-green-600 hover:bg-green-500 text-white"
                      : "bg-slate-600 hover:bg-slate-500",
                  )}
                >
                  {scenarioActive ? "SCENARIO ACTIVE" : "► START SCENARIO"}
                </Button>

                <p className="font-mono text-[8px] leading-snug text-muted-foreground">
                  Select a scenario, then press START to trigger the incident on the selected platform.
                </p>
              </div>
            )}
          </div>

          {/* mode switch */}
          <div className="pointer-events-auto flex rounded-lg border border-border bg-card/80 p-1 backdrop-blur-md">
            {(["elevated", "underground"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={cn(
                  "rounded-md px-3 py-2 font-mono text-xs font-medium transition-colors",
                  mode === m
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {m === "elevated" ? "ELEVATED" : "UNDERGROUND"}
              </button>
            ))}
          </div>
        </div>

        {/* Emergency banner */}
        {emergency && (
          <div className="pointer-events-none flex justify-center">
            <div
              className={cn(
                "animate-pulse rounded-md border px-5 py-2 backdrop-blur-md",
                anyStopped ? "border-red-500/70 bg-red-950/70" : "border-amber-500/70 bg-amber-950/70",
              )}
            >
              <p
                className={cn(
                  "font-mono text-sm font-bold uppercase tracking-wider",
                  anyStopped ? "text-red-300" : "text-amber-200",
                )}
              >
                {anyStopped
                  ? mode === "elevated"
                    ? "Emergency brake — BOTH trains STOPPED at station"
                    : "Emergency brake — Affected tunnel train STOPPED"
                  : "ESP ALERT — Intrusion detected · Press EMERGENCY BRAKE to stop train"}
              </p>
            </div>
          </div>
        )}

        {/* Bottom controls */}
        <div className="flex flex-wrap items-end justify-between gap-3">
          {/* Floating SCR button in bottom-left - Only for underground mode */}
          {mode === "underground" && (
            <div className="pointer-events-auto fixed left-4 bottom-4 z-50">
              <button
                onClick={() => setControlRoomOpen(!controlRoomOpen)}
                className={cn(
                  "rounded-full w-12 h-12 flex items-center justify-center font-mono font-bold text-lg transition-all duration-300 border-2",
                  anyPressed
                    ? "scr-panel-blink text-red-100 border-red-400"
                    : "border-slate-600 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:border-slate-500",
                )}
                title="Station Controller (SCR)"
              >
                SCR
              </button>
            </div>
          )}

          {/* SCR Floating Panel Box - Similar to Train Status - Only for underground mode */}
          {mode === "underground" && controlRoomOpen && (
            <>
              {/* Backdrop for closing */}
              <div
                className="pointer-events-auto fixed inset-0 z-40"
                onClick={() => setControlRoomOpen(false)}
              />

              {/* Compact SCR Box Panel - above SCR button */}
              <div
                className="pointer-events-auto fixed left-4 bottom-20 z-50 w-64 rounded-lg border border-border bg-card/90 p-2.5 backdrop-blur-md scr-panel-open shadow-2xl"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setControlRoomOpen(false)
                }}
              >
                {/* Header with close button */}
                <div className="flex items-center justify-between mb-2 pb-2 border-b border-border">
                  <p className="font-mono text-[8px] uppercase tracking-widest text-muted-foreground font-semibold">
                    Station Controller
                  </p>
                  <button
                    onClick={() => setControlRoomOpen(false)}
                    className="text-muted-foreground hover:text-foreground transition-colors text-lg font-bold w-5 h-5 flex items-center justify-center"
                    title="Close (Esc)"
                  >
                    ×
                  </button>
                </div>

                {/* Status indicator */}
                <div className="flex items-center gap-2 mb-2">
                  <StatusDot tone={anyPressed ? "alarm" : "ok"} />
                  <span className="font-mono text-[7px] uppercase tracking-widest text-muted-foreground">
                    {anyPressed ? "⚠ Alert" : "Nominal"}
                  </span>
                </div>

                {/* Alarm readout */}
                {anyPressed ? (
                  <div className="scr-panel-blink rounded-md border px-2 py-1 text-center mb-2">
                    <p className="scr-text-blink font-mono text-[8px] font-bold uppercase tracking-widest text-red-100">
                      ESP Alert
                    </p>
                    <div className="mt-0.5 flex flex-col gap-0.5">
                      {espPressed.A && (
                        <p className="scr-text-blink font-mono text-[7px] font-extrabold text-white">
                          ESP1
                        </p>
                      )}
                      {espPressed.B && (
                        <p className="scr-text-blink font-mono text-[7px] font-extrabold text-white">
                          ESP2
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="rounded-md border border-emerald-700/50 bg-emerald-950/40 px-2 py-1 text-center mb-2">
                    <p className="font-mono text-[7px] font-semibold uppercase tracking-widest text-emerald-300">
                      All Clear
                    </p>
                  </div>
                )}

                {/* Sensor badges */}
                <div className="flex items-stretch gap-1 mb-2">
                  <div
                    className={cn(
                      "flex flex-1 flex-col items-center gap-0.5 rounded-md border px-1 py-0.5 text-center transition-colors text-[6px]",
                      espPressed.A
                        ? "scr-panel-blink border-red-400 text-red-100"
                        : "border-border bg-secondary/40 text-muted-foreground",
                    )}
                  >
                    <span className="font-mono font-bold">ESP1</span>
                    <span className={cn("font-mono uppercase tracking-widest", espPressed.A && "scr-text-blink")}>
                      {espPressed.A ? "!" : "OK"}
                    </span>
                  </div>
                  <div
                    className={cn(
                      "flex flex-1 flex-col items-center gap-0.5 rounded-md border px-1 py-0.5 text-center transition-colors text-[6px]",
                      espPressed.B
                        ? "scr-panel-blink border-red-400 text-red-100"
                        : "border-border bg-secondary/40 text-muted-foreground",
                    )}
                  >
                    <span className="font-mono font-bold">ESP2</span>
                    <span className={cn("font-mono uppercase tracking-widest", espPressed.B && "scr-text-blink")}>
                      {espPressed.B ? "!" : "OK"}
                    </span>
                  </div>
                </div>

                {/* ESP buttons */}
                <div className="flex flex-col gap-1 border-t border-border pt-2 mb-2">
                  <button
                    onClick={() => handleESPClick("A")}
                    className={cn(
                      "rounded bg-red-600 px-2 py-1 font-mono text-[7px] font-bold text-white transition-all hover:bg-red-500",
                      blinkingButton === "A" && "esp-glow-blink border border-red-300",
                    )}
                  >
                    ESP 1
                  </button>
                  <button
                    onClick={() => handleESPClick("B")}
                    className={cn(
                      "rounded bg-red-600 px-2 py-1 font-mono text-[7px] font-bold text-white transition-all hover:bg-red-500",
                      blinkingButton === "B" && "esp-glow-blink border border-red-300",
                    )}
                  >
                    ESP 2
                  </button>
                </div>

                {/* Reset button */}
                <button
                  onClick={handleResetAll}
                  className="w-full rounded-md border border-border bg-secondary px-2 py-0.5 font-mono text-[7px] font-semibold uppercase tracking-widest text-secondary-foreground transition-colors hover:bg-accent"
                >
                  Reset
                </button>
              </div>
            </>
          )}

          {/* Floating Train Status button in bottom-right */}
          <div className="pointer-events-auto fixed right-4 bottom-4 z-50">
            <button
              onClick={() => setTrainStatusOpen(!trainStatusOpen)}
              className={cn(
                "rounded-full w-12 h-12 flex items-center justify-center font-mono font-bold text-lg transition-all duration-300 border-2",
                anyStopped
                  ? "border-red-400 bg-red-900/60 text-red-100 hover:bg-red-800/60"
                  : "border-blue-600 bg-blue-800 hover:bg-blue-700 text-blue-200 hover:border-blue-500",
              )}
              title="Train Status"
            >
              TRN
            </button>
          </div>

          {/* Train Status Floating Panel Box */}
          {trainStatusOpen && (
            <>
              {/* Backdrop for closing */}
              <div
                className="pointer-events-auto fixed inset-0 z-40"
                onClick={() => setTrainStatusOpen(false)}
              />

              {/* Compact Train Status Box Panel - above button */}
              <div
                className="pointer-events-auto fixed right-4 bottom-20 z-50 w-64 rounded-lg border border-border bg-card/90 p-2.5 backdrop-blur-md scr-panel-open shadow-2xl"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setTrainStatusOpen(false)
                }}
              >
                {/* Header with close button */}
                <div className="flex items-center justify-between mb-2 pb-2 border-b border-border">
                  <p className="font-mono text-[8px] uppercase tracking-widest text-muted-foreground font-semibold">
                    Train Status
                  </p>
                  <button
                    onClick={() => setTrainStatusOpen(false)}
                    className="text-muted-foreground hover:text-foreground transition-colors text-lg font-bold w-5 h-5 flex items-center justify-center"
                    title="Close (Esc)"
                  >
                    ×
                  </button>
                </div>

                {/* Train cards - compact */}
                <div className="grid grid-cols-2 gap-1.5 mb-2">
                  <TrainCard id="A" />
                  <TrainCard id="B" />
                </div>

                {/* Track controls */}
                <div className="flex flex-col gap-1.5 border-t border-border pt-2">
                  <div>
                    <p className="mb-0.5 font-mono text-[7px] uppercase tracking-widest text-muted-foreground font-semibold">
                      Track A
                    </p>
                    <TrackControls id="A" />
                  </div>
                  <div>
                    <p className="mb-0.5 font-mono text-[7px] uppercase tracking-widest text-muted-foreground font-semibold">
                      Track B
                    </p>
                    <TrackControls id="B" />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  )
}
