"use client"

import { useMemo } from "react"
import { Sky } from "@react-three/drei"
import { useEsp } from "@/lib/esp-store"
import { useFallingPerson } from "@/lib/falling-person-context"
import { Train } from "./train"
import {
  Track,
  TrackCircuit,
  Platform,
  Railing,
  CCTV,
  PIDS,
  Signboard,
  LightPole,
  FallingHazard,
  EspPost,
  Crowd,
  PlatformController,
} from "./elements"

// The platform is intentionally SHORTER than the running track so the train
// has a long approach (TC1) and a long departure (TC3) zone either side of
// the station — room for the full emergency-braking distance to play out.
const PLATFORM_LEN = 72
const TRACK_LEN = 240
const APPROACH_LEN = (TRACK_LEN - PLATFORM_LEN) / 2 // TC1 / TC3 segment length
const ROOF_Y = 7.4

const TRACK_A_X = -1.7
const TRACK_B_X = 1.7
const PLAT_L_X = -5.6 // left platform centre (edge at -3.1)
const PLAT_R_X = 5.6 // right platform centre (edge at +3.1)

function Roof() {
  // steel space-frame roof with sloped panels
  const trusses = useMemo(() => {
    const arr: number[] = []
    for (let z = -PLATFORM_LEN / 2; z <= PLATFORM_LEN / 2; z += 4) arr.push(z)
    return arr
  }, [])

  return (
    <group>
      {/* main roof panels (gentle butterfly) */}
      <mesh position={[-4.4, ROOF_Y + 0.6, 0]} rotation={[0, 0, 0.12]}>
        <boxGeometry args={[10, 0.15, PLATFORM_LEN]} />
        <meshStandardMaterial color="#dfe3e8" metalness={0.4} roughness={0.5} transparent opacity={0.32} />
      </mesh>
      <mesh position={[4.4, ROOF_Y + 0.6, 0]} rotation={[0, 0, -0.12]}>
        <boxGeometry args={[10, 0.15, PLATFORM_LEN]} />
        <meshStandardMaterial color="#dfe3e8" metalness={0.4} roughness={0.5} transparent opacity={0.32} />
      </mesh>
      {/* central ridge skylight */}
      <mesh position={[0, ROOF_Y + 1.2, 0]}>
        <boxGeometry args={[1.4, 0.06, PLATFORM_LEN]} />
        <meshStandardMaterial color="#bfe6ff" transparent opacity={0.5} metalness={0.2} roughness={0.05} />
      </mesh>

      {/* steel trusses across roof */}
      {trusses.map((z) => (
        <mesh key={z} position={[0, ROOF_Y + 0.9, z]}>
          <boxGeometry args={[18.5, 0.12, 0.12]} />
          <meshStandardMaterial color="#8c9298" metalness={0.7} roughness={0.4} />
        </mesh>
      ))}

      {/* longitudinal beams */}
      {[-8, -4, 0, 4, 8].map((x) => (
        <mesh key={x} position={[x, ROOF_Y + 0.75, 0]}>
          <boxGeometry args={[0.14, 0.14, PLATFORM_LEN]} />
          <meshStandardMaterial color="#8c9298" metalness={0.7} roughness={0.4} />
        </mesh>
      ))}
    </group>
  )
}

function Columns() {
  const zs = useMemo(() => {
    const arr: number[] = []
    for (let z = -PLATFORM_LEN / 2 + 4; z <= PLATFORM_LEN / 2 - 4; z += 12) arr.push(z)
    return arr
  }, [])
  return (
    <group>
      {zs.map((z) =>
        [-8.3, 8.3].map((x) => (
          <group key={`${x}-${z}`} position={[x, 0, z]}>
            <mesh castShadow position={[0, ROOF_Y / 2, 0]}>
              <cylinderGeometry args={[0.22, 0.26, ROOF_Y, 16]} />
              <meshStandardMaterial color="#cfd3d8" metalness={0.5} roughness={0.5} />
            </mesh>
            {/* capital bracket */}
            <mesh position={[x > 0 ? -0.6 : 0.6, ROOF_Y - 0.3, 0]} rotation={[0, 0, x > 0 ? 0.5 : -0.5]}>
              <boxGeometry args={[1.4, 0.12, 0.3]} />
              <meshStandardMaterial color="#8c9298" metalness={0.6} roughness={0.4} />
            </mesh>
          </group>
        )),
      )}
    </group>
  )
}

export function ElevatedStation() {
  const { occupancy, espActive, personFall, emergencyBrake, trainStopped, trainSpeedKmh, running, resetCount } = useEsp()
  const { fallen, fallStart, fallKind } = useFallingPerson()

  const circuitState = (t: "A" | "B") =>
    occupancy[t] === "occupied" ? "occupied" : espActive[t] ? "armed" : "clear"

  return (
    <group>
      <Sky sunPosition={[40, 30, -60]} turbidity={2} rayleigh={0.6} />
      <hemisphereLight args={["#dff0ff", "#5a5a55", 1.1]} />
      <directionalLight
        position={[20, 35, 15]}
        intensity={2.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-near={1}
        shadow-camera-far={120}
        shadow-camera-left={-40}
        shadow-camera-right={40}
        shadow-camera-top={40}
        shadow-camera-bottom={-40}
      />

      {/* elevated viaduct deck */}
      <mesh receiveShadow position={[0, -0.55, 0]}>
        <boxGeometry args={[19, 0.6, TRACK_LEN + 18]} />
        <meshStandardMaterial color="#b9b6ae" roughness={0.95} />
      </mesh>
      {/* deck underside girders giving "elevated" read */}
      {[-7, 0, 7].map((x) => (
        <mesh key={x} position={[x, -1.4, 0]}>
          <boxGeometry args={[1, 1.4, TRACK_LEN + 18]} />
          <meshStandardMaterial color="#9a978f" roughness={1} />
        </mesh>
      ))}

      <Roof />
      <Columns />

      {/* central guideway: two adjacent tracks = ONE shared risk zone */}
      <Track x={TRACK_A_X} length={TRACK_LEN} />
      <Track x={TRACK_B_X} length={TRACK_LEN} />

      {/* shared-zone floor highlight under both tracks */}
      <mesh position={[0, -0.27, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[6.4, TRACK_LEN]} />
        <meshBasicMaterial
          color={espActive.A || espActive.B ? "#ff6b2d" : "#1fb6ff"}
          transparent
          opacity={espActive.A || espActive.B ? 0.12 : 0.05}
        />
      </mesh>

      {/* Three segmented track circuits per guideway:
          TC1 = approach (before platforms), TC2 = station/platform zone,
          TC3 = departure (after platforms). The intrusion happens in the
          platform zone, so TC2 carries the occupied state; the approach &
          departure circuits show ARMED while ESP is tripped. */}
      {(["A", "B"] as const).map((t) => {
        const tx = t === "A" ? TRACK_A_X : TRACK_B_X
        const stationState = circuitState(t)
        const endState: "clear" | "armed" = espActive[t] ? "armed" : "clear"
        // labels read upright from the platform-side viewpoint
        const labelRot = t === "A" ? 0 : Math.PI
        return (
          <group key={`tc-${t}`}>
            {/* TC1 — long approach before the platform */}
            <TrackCircuit
              x={tx}
              z={-(PLATFORM_LEN / 2 + APPROACH_LEN / 2)}
              length={APPROACH_LEN}
              state={endState}
              label={`TC1·${t}`}
              labelRotation={labelRot}
            />
            {/* TC2 — station / platform zone */}
            <TrackCircuit
              x={tx}
              z={0}
              length={PLATFORM_LEN}
              state={stationState}
              label={`TC2·${t}`}
              labelRotation={labelRot}
            />
            {/* TC3 — long departure after the platform (braking distance plays out here) */}
            <TrackCircuit
              x={tx}
              z={PLATFORM_LEN / 2 + APPROACH_LEN / 2}
              length={APPROACH_LEN}
              state={endState}
              label={`TC3·${t}`}
              labelRotation={labelRot}
            />
          </group>
        )
      })}

      {/* clickable intrusion zones over each track */}
      {(["A", "B"] as const).map((t) => (
        <mesh
          key={t}
          position={[t === "A" ? TRACK_A_X : TRACK_B_X, 0.05, 0]}
          rotation={[-Math.PI / 2, 0, 0]}
          onClick={(e) => {
            e.stopPropagation()
            personFall(t)
          }}
          onPointerOver={(e) => {
            e.stopPropagation()
            document.body.style.cursor = "pointer"
          }}
          onPointerOut={() => {
            document.body.style.cursor = "auto"
          }}
        >
          <planeGeometry args={[2.6, PLATFORM_LEN]} />
          <meshBasicMaterial transparent opacity={0} />
        </mesh>
      ))}

      {/* side platforms */}
      <Platform x={PLAT_L_X} width={5} length={PLATFORM_LEN} edgeSide={1} />
      <Platform x={PLAT_R_X} width={5} length={PLATFORM_LEN} edgeSide={-1} />

      {/* platform-back safety railings */}
      <Railing x={PLAT_L_X - 2.5} length={PLATFORM_LEN} y={1.1} />
      <Railing x={PLAT_R_X + 2.5} length={PLATFORM_LEN} y={1.1} />

      {/* falling person + object hazards */}
      {fallen.A && fallStart.A > 0 && (
        <FallingHazard x={TRACK_A_X} z={4} groundY={0.05} startTime={fallStart.A} kind={fallKind.A} />
      )}
      {fallen.B && fallStart.B > 0 && (
        <FallingHazard x={TRACK_B_X} z={-4} groundY={0.05} startTime={fallStart.B} kind={fallKind.B} />
      )}

      {/* waiting passengers along both platforms (kept back from the edge) */}
      <Crowd count={20} xRange={[PLAT_L_X - 2, PLAT_L_X + 1.4]} zRange={[-32, 32]} y={1.1} facing={-Math.PI / 2} />
      <Crowd count={20} xRange={[PLAT_R_X - 1.4, PLAT_R_X + 2]} zRange={[-32, 32]} y={1.1} facing={Math.PI / 2} />

      {/* ESP plungers on each platform */}
      <EspPost position={[PLAT_L_X - 1.8, 1.1, 8]} active={espActive.A || espActive.B} onClick={() => setTimeout(() => emergencyBrake("A"), 2000)} />
      <EspPost position={[PLAT_R_X + 1.8, 1.1, -8]} active={espActive.A || espActive.B} onClick={() => setTimeout(() => emergencyBrake("B"), 2000)} />

      {/* platform controllers standing by the ESP */}
      <PlatformController
        position={[PLAT_L_X - 1.1, 1.1, 8]}
        rotation={Math.PI}
        active={espActive.A || espActive.B}
      />
      <PlatformController
        position={[PLAT_R_X + 1.1, 1.1, -8]}
        rotation={0}
        active={espActive.A || espActive.B}
      />

      {/* PIDS displays hanging from roof */}
      <PIDS
        position={[PLAT_L_X + 1.5, 4.4, -12]}
        rotation={[0, -0.25, 0]}
        line1="PLATFORM 1  >  AIRPORT"
        line2={espActive.A ? "SERVICE HELD" : "TRAIN  2 MIN"}
        alarm={espActive.A}
      />
      <PIDS
        position={[PLAT_R_X - 1.5, 4.4, 12]}
        rotation={[0, Math.PI + 0.25, 0]}
        line1="PLATFORM 2  >  CITY CENTRE"
        line2={espActive.B ? "SERVICE HELD" : "TRAIN  1 MIN"}
        alarm={espActive.B}
      />

      {/* station name signboards */}
      <Signboard position={[PLAT_L_X + 1.2, 3.1, 18]} rotation={[0, -0.2, 0]} label="CENTRAL JUNCTION" />
      <Signboard position={[PLAT_R_X - 1.2, 3.1, -18]} rotation={[0, Math.PI + 0.2, 0]} label="CENTRAL JUNCTION" />

      {/* CCTV cameras */}
      <CCTV position={[PLAT_L_X + 2, 4.0, 0]} rotation={[0.3, -0.5, 0]} />
      <CCTV position={[PLAT_R_X - 2, 4.0, -20]} rotation={[0.3, Math.PI + 0.5, 0]} />
      <CCTV position={[0, ROOF_Y - 0.5, 22]} rotation={[0.4, Math.PI, 0]} />

      {/* lighting / electrical poles along platforms */}
      {[-30, -15, 0, 15, 30].map((z) => (
        <LightPole key={`l${z}`} position={[PLAT_L_X - 2.2, 0, z]} />
      ))}
      {[-30, -15, 0, 15, 30].map((z) => (
        <LightPole key={`r${z}`} position={[PLAT_R_X + 2.2, 0, z]} />
      ))}

      {/* the two trains, aligned & visually close to show shared risk zone.
          `dock` makes each train run the same arrive → open doors → dwell →
          depart cycle used in the underground station, instead of cruising
          straight through the platform. `resetSignal` (bumped every ESP
          RESET) forces a frozen/mid-cycle train to cleanly restart its
          approach rather than idling out a stale phase. */}
      <Train
        x={TRACK_A_X}
        stopped={!running || trainStopped.A}
        color="#eef0f2"
        accentColor="#1d4ed8"
        speedKmh={trainSpeedKmh.A}
        direction={-1}
        startZ={6}
        loopLimit={TRACK_LEN / 2}
        label={`TRAIN A · ${trainSpeedKmh.A} km/h`}
        dock
        dockZ={0}
        platformSide={-1}
        dwellSeconds={1}
        resetSignal={resetCount}
      />
      <Train
        x={TRACK_B_X}
        stopped={!running || trainStopped.B}
        color="#eef0f2"
        accentColor="#0e9f6e"
        speedKmh={trainSpeedKmh.B}
        direction={1}
        startZ={-10}
        loopLimit={TRACK_LEN / 2}
        label={`TRAIN B · ${trainSpeedKmh.B} km/h`}
        dock
        dockZ={0}
        platformSide={1}
        dwellSeconds={1}
        resetSignal={resetCount}
      />
    </group>
  )
}
