"use client"

import { useMemo, useRef } from "react"
import * as THREE from "three"
import { useFrame } from "@react-three/fiber"
import { useEsp, type TrackId } from "@/lib/esp-store"
import { useFallingPerson } from "@/lib/falling-person-context"
import { usePlatformESP } from "@/lib/platform-esp-context"
import { useDoorSync } from "@/lib/door-sync-context"
import { Train } from "./train"
import { BarrierGate } from "./barrier-gate"
import { PlatformScreenDoor } from "./platform-screen-door"
import {
  Track,
  TrackCircuit,
  CCTV,
  PIDS,
  Signboard,
  FallingHazard,
  EspPost,
  Crowd,
  PlatformController,
} from "./elements"

/* ------------------------------------------------------------------ */
/* Modern island-platform underground station                          */
/*   - wide reflective tiled island platform in the centre             */
/*   - full-height platform screen doors (PSDs) on both edges          */
/*   - trains with magenta livery docked either side                   */
/*   - faceted white folded-plate ceiling with recessed light channels */
/* ------------------------------------------------------------------ */

const STATION_LEN = 80 // platform length (slab, PSDs, ceiling, columns)
const HALF = STATION_LEN / 2

const TRACK_LEN = 130 // rails run well beyond the platform on both ends
const TRACK_HALF = TRACK_LEN / 2

const PLATFORM_HW = 3.6 // island platform half-width (edge at ±3.6)
const PLATFORM_TOP = 1.15
const PSD_X = 3.6 // platform-screen-door line
const TRACK_X = 6.4 // track / train centre
const WALL_X = 9.2 // outer tunnel wall
const CEIL_Y = 7.2

const ACCENT = "#0066cc" // station blue line colour

/* ---------------------- Faceted folded-plate ceiling --------------- */
function Ceiling() {
  const segs = useMemo(() => {
    const arr: number[] = []
    for (let z = -HALF + 2; z <= HALF - 2; z += 3.8) arr.push(z)
    return arr
  }, [])

  return (
    <group>
      {/* dark structural deck above the panels */}
      <mesh position={[0, CEIL_Y + 0.7, 0]}>
        <boxGeometry args={[WALL_X * 2 + 2, 0.4, STATION_LEN]} />
        <meshStandardMaterial color="#1b1d21" roughness={1} />
      </mesh>

      {segs.map((z) => (
        <group key={z} position={[0, 0, z]}>
          {/* left white facet — tilts up toward the centre ridge */}
          <mesh position={[-4.4, CEIL_Y, 0]} rotation={[0, 0, 0.17]} castShadow>
            <boxGeometry args={[9, 0.14, 3.4]} />
            <meshStandardMaterial color="#eef1f4" metalness={0.25} roughness={0.55} />
          </mesh>
          {/* right white facet */}
          <mesh position={[4.4, CEIL_Y, 0]} rotation={[0, 0, -0.17]} castShadow>
            <boxGeometry args={[9, 0.14, 3.4]} />
            <meshStandardMaterial color="#eef1f4" metalness={0.25} roughness={0.55} />
          </mesh>
          {/* central dark perforated channel */}
          <mesh position={[0, CEIL_Y + 0.55, 0]}>
            <boxGeometry args={[1.5, 0.12, 3.4]} />
            <meshStandardMaterial color="#15171a" roughness={1} />
          </mesh>
        </group>
      ))}

      {/* recessed linear light strips running the length of the platform */}
      {[-4.6, 0, 4.6].map((x) => (
        <mesh key={x} position={[x, CEIL_Y + 0.42, 0]}>
          <boxGeometry args={[0.5, 0.06, STATION_LEN - 6]} />
          <meshStandardMaterial color="#f7fbff" emissive="#eaf4ff" emissiveIntensity={1.8} />
        </mesh>
      ))}

      {/* soft fill from the ceiling so the platform glows evenly */}
      {[-20, 20].map((z) => (
        <pointLight key={z} position={[0, CEIL_Y - 0.4, z]} intensity={18} distance={32} color="#eef4ff" />
      ))}
    </group>
  )
}

/* ---------------------- Visible lit running tunnel ---------------- */
function TunnelSide({ x }: { x: number }) {
  const dir = Math.sign(x)
  return (
    <group>
      {/* outer tunnel wall — lightened so the train reads clearly */}
      <mesh position={[dir * WALL_X, 3.2, 0]} rotation={[0, dir > 0 ? -Math.PI / 2 : Math.PI / 2, 0]} receiveShadow>
        <planeGeometry args={[TRACK_LEN, 7]} />
        <meshStandardMaterial color="#7f878f" roughness={0.9} />
      </mesh>

      {/* continuous recessed light strip running the length of the tunnel crown */}
      <mesh position={[x, 7.85, 0]}>
        <boxGeometry args={[0.5, 0.08, TRACK_LEN - 4]} />
        <meshStandardMaterial color="#f7fbff" emissive="#eaf4ff" emissiveIntensity={2.2} />
      </mesh>

      {/* accent line along the wall */}
      <mesh position={[dir * (WALL_X - 0.02), 4.6, 0]} rotation={[0, dir > 0 ? -Math.PI / 2 : Math.PI / 2, 0]}>
        <planeGeometry args={[TRACK_LEN, 0.18]} />
        <meshStandardMaterial color={ACCENT} emissive={ACCENT} emissiveIntensity={0.5} />
      </mesh>

      {/* tunnel portals where the track leaves the platform at each end */}
      {[-HALF, HALF].map((z) => (
        <group key={z} position={[x, 0, z]}>
          {/* portal head beam */}
          <mesh position={[0, 5.0, 0]}>
            <boxGeometry args={[4.0, 0.5, 0.5]} />
            <meshStandardMaterial color="#d8dce0" metalness={0.2} roughness={0.6} />
          </mesh>
          {/* portal jambs */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 1.9, 2.55, 0]}>
              <boxGeometry args={[0.4, 5.4, 0.5]} />
              <meshStandardMaterial color="#d8dce0" metalness={0.2} roughness={0.6} />
            </mesh>
          ))}
          {/* fill above the portal head */}
          <mesh position={[0, 6.6, 0]}>
            <boxGeometry args={[6, 2.8, 0.28]} />
            <meshStandardMaterial color="#6e767e" roughness={0.95} />
          </mesh>
          {/* fill beside each jamb out to the wall */}
          {[-1, 1].map((s) => (
            <mesh key={s} position={[s * 4.05, 3.0, 0]}>
              <boxGeometry args={[2.1, 6, 0.28]} />
              <meshStandardMaterial color="#6e767e" roughness={0.95} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  )
}

/* ---------------------- Island platform floor --------------------- */
function IslandPlatform() {
  return (
    <group>
      {/* platform slab */}
      <mesh position={[0, PLATFORM_TOP / 2, 0]} receiveShadow>
        <boxGeometry args={[PLATFORM_HW * 2, PLATFORM_TOP, STATION_LEN]} />
        <meshStandardMaterial color="#c9ccd0" roughness={0.9} />
      </mesh>

      {/* glossy tiled deck; static material avoids the costly live reflection pass */}
      <mesh position={[0, PLATFORM_TOP + 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[PLATFORM_HW * 2, STATION_LEN]} />
        <meshStandardMaterial color="#d7dadf" metalness={0.18} roughness={0.48} />
      </mesh>

      {/* tactile warning strips + dark nosing on both edges */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * (PLATFORM_HW - 0.35), PLATFORM_TOP + 0.012, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[0.5, STATION_LEN]} />
            <meshStandardMaterial color="#f4c430" emissive="#5a4500" emissiveIntensity={0.2} roughness={0.7} />
          </mesh>
          <mesh position={[s * PLATFORM_HW, PLATFORM_TOP - 0.02, 0]}>
            <boxGeometry args={[0.08, 0.14, STATION_LEN]} />
            <meshStandardMaterial color="#222" roughness={0.6} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

/* ---------------------- Square columns down the centre ------------ */
function Columns() {
  const zs = useMemo(() => [-24, -8, 8, 24], [])
  return (
    <group>
      {zs.map((z) => (
        <group key={z} position={[0, 0, z]}>
          <mesh position={[0, (PLATFORM_TOP + CEIL_Y) / 2, 0]} castShadow>
            <boxGeometry args={[0.8, CEIL_Y - PLATFORM_TOP, 0.8]} />
            <meshStandardMaterial color="#dfe2e6" metalness={0.2} roughness={0.6} />
          </mesh>
          {/* skirting accent */}
          <mesh position={[0, PLATFORM_TOP + 0.5, 0]}>
            <boxGeometry args={[0.86, 0.1, 0.86]} />
            <meshStandardMaterial color="#9aa0a6" metalness={0.4} roughness={0.5} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

/* ---------------------- Per-track running side -------------------- */
function RunningSide({ id }: { id: TrackId }) {
  const { occupancy, espActive, trainStopped, trainSpeedKmh, personFall, running, resetCount } = useEsp()
  const { fallen, fallStart, fallKind } = useFallingPerson()
  const { state } = useDoorSync()
  const occupied = occupancy[id] === "occupied"
  const armed = espActive[id]
  const circuit = occupied ? "occupied" : armed ? "armed" : "clear"
  const x = id === "A" ? -TRACK_X : TRACK_X

  return (
    <group>
      <TunnelSide x={x} />

      {/* track bed slab */}
      <mesh position={[x, -0.02, 0]} receiveShadow>
        <boxGeometry args={[3.6, 0.04, TRACK_LEN]} />
        <meshStandardMaterial color="#26282b" roughness={1} />
      </mesh>

      <Track x={x} length={TRACK_LEN} />
      <TrackCircuit x={x} length={TRACK_LEN} width={2.4} state={circuit} />

      {/* clickable intrusion zone over the track */}
      <mesh
        position={[x, 0.08, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        onClick={(e) => {
          e.stopPropagation()
          personFall(id)
        }}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = "pointer"
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto"
        }}
      >
        <planeGeometry args={[2.6, TRACK_LEN]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {fallen[id] && fallStart[id] > 0 && (
        <FallingHazard x={x} z={id === "A" ? 4 : -4} groundY={0.06} startTime={fallStart[id]} kind={fallKind[id]} />
      )}

      {/* the train docked / running on this side */}
      <Train
        x={x}
        stopped={!running || trainStopped[id]}
        color="#eef0f2"
        accentColor={ACCENT}
        speedKmh={trainSpeedKmh[id]}
        direction={id === "A" ? -1 : 1}
        startZ={id === "A" ? 4 : -6}
        loopLimit={TRACK_HALF}
        label={`TRAIN ${id}`}
        dock
        dockZ={0}
        platformSide={-1}
        stuckObject={id === "A"}
        track={id}
        resetSignal={resetCount}
      />
    </group>
  )
}

export function UndergroundStation() {
  const { espActive, trainStopped, personFall, emergencyBrake } = useEsp()
  const { espPressed, triggerPlatformESP } = usePlatformESP()
  const { state } = useDoorSync()
  const armedAny = espActive.A || espActive.B

  const handlePlatformESP = (platform: "A" | "B") => {
    triggerPlatformESP(platform)
    emergencyBrake(platform)
  }

  // Create refs that mirror the context state for smooth animation
  const barrierARef = useRef(state.barrierOpenA)
  const barrierBRef = useRef(state.barrierOpenB)
  const psdARef = useRef(state.psdOpenA)
  const psdBRef = useRef(state.psdOpenB)

  // Update refs when state changes
  useFrame(() => {
    barrierARef.current = state.barrierOpenA
    barrierBRef.current = state.barrierOpenB
    psdARef.current = state.psdOpenA
    psdBRef.current = state.psdOpenB
  })

  return (
    <group>
      {/* bright, even interior lighting for the white station */}
      <ambientLight intensity={0.85} color="#eef2f7" />
      <hemisphereLight args={["#f2f6fb", "#3a3d42", 0.9]} />
      <directionalLight position={[6, 18, 12]} intensity={1.1} color="#eaf0f7" />
      {/* service lighting near each train */}
      <pointLight position={[0, 3.2, 0]} intensity={24} distance={34} color="#e6eef8" />

      <Ceiling />
      <IslandPlatform />
      <Columns />

      <RunningSide id="A" />
      <RunningSide id="B" />

      {/* Platform Screen Doors (PSDs) — transparent glass doors that slide open on both platform edges */}
      <PlatformScreenDoor
        x={-PSD_X}
        length={STATION_LEN}
        psdOpenRef={psdARef}
        accent={ACCENT}
        stuckObject
        stuckObjectFallen={espPressed.A}
      />
      <PlatformScreenDoor x={PSD_X} length={STATION_LEN} psdOpenRef={psdBRef} accent={ACCENT} />

      {/* Rotating arm barrier gates at platform entries — one per track */}
      <BarrierGate x={-PLATFORM_HW - 0.1} z={-HALF + 6} barrierOpenRef={barrierARef} accent={ACCENT} />
      <BarrierGate x={-PLATFORM_HW - 0.1} z={HALF - 6} barrierOpenRef={barrierARef} accent={ACCENT} />
      <BarrierGate x={PLATFORM_HW + 0.1} z={-HALF + 6} barrierOpenRef={barrierBRef} accent={ACCENT} />
      <BarrierGate x={PLATFORM_HW + 0.1} z={HALF - 6} barrierOpenRef={barrierBRef} accent={ACCENT} />

      {/* ESP plungers + controllers on the island platform, one per edge */}
      <EspPost position={[-PLATFORM_HW + 0.4, PLATFORM_TOP, 8]} active={armedAny} onClick={() => handlePlatformESP("A")} />
      <PlatformController
        position={[-PLATFORM_HW + 1.1, PLATFORM_TOP, 8]}
        rotation={-Math.PI / 2}
        active={espActive.A}
        onClick={() => handlePlatformESP("A")}
      />
      <EspPost position={[PLATFORM_HW - 0.4, PLATFORM_TOP, -8]} active={armedAny} onClick={() => handlePlatformESP("B")} />
      <PlatformController
        position={[PLATFORM_HW - 1.1, PLATFORM_TOP, -8]}
        rotation={Math.PI / 2}
        active={espActive.B}
        onClick={() => handlePlatformESP("B")}
      />

      {/* Platform number signboards — visible indicators */}
      {/* Platform 1 signboard */}
      <mesh position={[-PLATFORM_HW + 0.5, PLATFORM_TOP + 2.2, -HALF + 4]}>
        <boxGeometry args={[1.0, 1.2, 0.08]} />
        <meshStandardMaterial color="#1a3a50" roughness={0.6} metalness={0.2} />
      </mesh>
      <mesh position={[-PLATFORM_HW + 0.5, PLATFORM_TOP + 2.2, -HALF + 4.05]}>
        <planeGeometry args={[0.9, 1.1]} />
        <meshStandardMaterial color="#f0f4f8" emissive="#e0e8f0" emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[-PLATFORM_HW + 0.5, PLATFORM_TOP + 2.2, -HALF + 4.08]}>
        <boxGeometry args={[0.8, 0.5, 0.04]} />
        <meshStandardMaterial color="#ffc966" emissive="#ffc966" emissiveIntensity={0.4} />
      </mesh>

      {/* Platform 2 signboard */}
      <mesh position={[PLATFORM_HW - 0.5, PLATFORM_TOP + 2.2, -HALF + 4]}>
        <boxGeometry args={[1.0, 1.2, 0.08]} />
        <meshStandardMaterial color="#1a3a50" roughness={0.6} metalness={0.2} />
      </mesh>
      <mesh position={[PLATFORM_HW - 0.5, PLATFORM_TOP + 2.2, -HALF + 4.05]}>
        <planeGeometry args={[0.9, 1.1]} />
        <meshStandardMaterial color="#f0f4f8" emissive="#e0e8f0" emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[PLATFORM_HW - 0.5, PLATFORM_TOP + 2.2, -HALF + 4.08]}>
        <boxGeometry args={[0.8, 0.5, 0.04]} />
        <meshStandardMaterial color="#56d8ff" emissive="#56d8ff" emissiveIntensity={0.4} />
      </mesh>

      {/* waiting passengers spread across the island platform */}
      <Crowd count={2} xRange={[-PLATFORM_HW + 0.6, PLATFORM_HW - 0.6]} zRange={[-30, 30]} y={PLATFORM_TOP} facing={0} />

      {/* interactive click zones on platform for person fall simulation */}
      {/* Platform A left side — person fall trigger */}
      <mesh
        position={[-PLATFORM_HW / 2, PLATFORM_TOP, -15]}
        onClick={() => personFall("A")}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = "pointer"
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto"
        }}
      >
        <boxGeometry args={[4, 1, 6]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {/* Platform A right side — person fall trigger */}
      <mesh
        position={[-PLATFORM_HW / 2, PLATFORM_TOP, 15]}
        onClick={() => personFall("A")}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = "pointer"
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto"
        }}
      >
        <boxGeometry args={[4, 1, 6]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {/* Platform B left side — person fall trigger */}
      <mesh
        position={[PLATFORM_HW / 2, PLATFORM_TOP, -15]}
        onClick={() => personFall("B")}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = "pointer"
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto"
        }}
      >
        <boxGeometry args={[4, 1, 6]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {/* Platform B right side — person fall trigger */}
      <mesh
        position={[PLATFORM_HW / 2, PLATFORM_TOP, 15]}
        onClick={() => personFall("B")}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = "pointer"
        }}
        onPointerOut={() => {
          document.body.style.cursor = "auto"
        }}
      >
        <boxGeometry args={[4, 1, 6]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>

      {/* PIDS hanging over each platform edge — larger display, no alarm colors */}
      <PIDS
        position={[-PLATFORM_HW + 0.3, 4.3, -14]}
        rotation={[0, -Math.PI / 2, 0]}
        line1="PLATFORM 1  >  NORTHBOUND"
        line2={trainStopped.A ? "SERVICE HELD" : "TRAIN  2 MIN"}
        alarm={false}
      />
      <PIDS
        position={[PLATFORM_HW - 0.3, 4.3, 14]}
        rotation={[0, Math.PI / 2, 0]}
        line1="PLATFORM 2  >  SOUTHBOUND"
        line2={trainStopped.B ? "SERVICE HELD" : "TRAIN  1 MIN"}
        alarm={false}
      />

      {/* station name signboards hanging above the platform */}
      <Signboard position={[0, 4.6, -20]} rotation={[0, 0, 0]} label="CENTRAL INTERCHANGE" color={ACCENT} width={3} />
      <Signboard position={[0, 4.6, 20]} rotation={[0, Math.PI, 0]} label="CENTRAL INTERCHANGE" color={ACCENT} width={3} />

      {/* CCTV cameras watching both platform edges */}
      <CCTV position={[-PLATFORM_HW + 0.5, 4.2, 0]} rotation={[0.3, -Math.PI / 2 + 0.4, 0]} />
      <CCTV position={[PLATFORM_HW - 0.5, 4.2, 0]} rotation={[0.3, Math.PI / 2 - 0.4, 0]} />

      {/* floor slab below to ground the scene */}
      <mesh position={[0, -0.05, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[WALL_X * 2 + 4, TRACK_LEN + 6]} />
        <meshStandardMaterial color="#1c1e22" roughness={1} />
      </mesh>
    </group>
  )
}
